export interface DominoTileData {
  left: number;
  right: number;
}

export type BoardEnd = 'LEFT' | 'RIGHT';
export type PlayerSeat = 'HOST' | 'GUEST' | 'BOT';
export type GamePhase = 'IDLE' | 'PLAYING' | 'ROUND_OVER' | 'MATCH_OVER';
export type RoundEndReason = 'DOMINO_OUT' | 'BLOCKED_BOARD';

export interface PlacedTile {
  tile: DominoTileData;
  playedBy: PlayerSeat;
}

export interface LegalMove {
  tile: DominoTileData;
  end: BoardEnd;
}

export interface RoundSummary {
  roundNumber: number;
  winner: PlayerSeat | null;
  reason: RoundEndReason;
  pointsAwarded: number;
  hostRemainingPips: number;
  guestRemainingPips: number;
}

export interface DominoGameState {
  roundNumber: number;
  targetScore: number;
  phase: GamePhase;
  board: PlacedTile[];
  leftEnd: number | null;
  rightEnd: number | null;
  hostHand: DominoTileData[];
  guestHand: DominoTileData[];
  boneyard: DominoTileData[];
  currentTurn: PlayerSeat;
  hostScore: number;
  guestScore: number;
  consecutivePasses: number;
  lastRoundSummary: RoundSummary | null;
  lastActionArabic: string;
  isVsBot: boolean;
}

export function tileId(tile: DominoTileData): string {
  return `${Math.min(tile.left, tile.right)}-${Math.max(tile.left, tile.right)}`;
}

export function isDouble(tile: DominoTileData): boolean {
  return tile.left === tile.right;
}

export function pipSum(tile: DominoTileData): number {
  return tile.left + tile.right;
}

export function flipTile(tile: DominoTileData): DominoTileData {
  return { left: tile.right, right: tile.left };
}

export function tileMatches(tile: DominoTileData, pip: number): boolean {
  return tile.left === pip || tile.right === pip;
}

export function createFullDoubleSixSet(): DominoTileData[] {
  const tiles: DominoTileData[] = [];
  for (let i = 0; i <= 6; i++) {
    for (let j = i; j <= 6; j++) {
      tiles.push({ left: i, right: j });
    }
  }
  return tiles;
}

function shuffle<T>(items: T[]): T[] {
  const arr = [...items];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

function determineOpeningSeat(
  hostHand: DominoTileData[],
  guestHand: DominoTileData[],
  opponentSeat: PlayerSeat
): PlayerSeat {
  const hostDouble = Math.max(-1, ...hostHand.filter(isDouble).map((t) => t.left));
  const guestDouble = Math.max(-1, ...guestHand.filter(isDouble).map((t) => t.left));
  if (hostDouble !== guestDouble) {
    return hostDouble > guestDouble ? 'HOST' : opponentSeat;
  }
  const hostMax = Math.max(-1, ...hostHand.map(pipSum));
  const guestMax = Math.max(-1, ...guestHand.map(pipSum));
  return hostMax >= guestMax ? 'HOST' : opponentSeat;
}

export function handForSeat(state: DominoGameState, seat: PlayerSeat): DominoTileData[] {
  return seat === 'HOST' ? state.hostHand : state.guestHand;
}

export function opponentSeatOf(state: DominoGameState): PlayerSeat {
  return state.isVsBot ? 'BOT' : 'GUEST';
}

export function startNewMatch(targetScore = 101, isVsBot = true): DominoGameState {
  return startRound(
    {
      roundNumber: 0,
      targetScore,
      phase: 'IDLE',
      board: [],
      leftEnd: null,
      rightEnd: null,
      hostHand: [],
      guestHand: [],
      boneyard: [],
      currentTurn: 'HOST',
      hostScore: 0,
      guestScore: 0,
      consecutivePasses: 0,
      lastRoundSummary: null,
      lastActionArabic: 'جاهز لبدء الجولة',
      isVsBot,
    },
    null
  );
}

export function startRound(
  previous: DominoGameState,
  previousRoundWinner: PlayerSeat | null
): DominoGameState {
  const deck = shuffle(createFullDoubleSixSet());
  const hostHand = deck.slice(0, 7);
  const guestHand = deck.slice(7, 14);
  const boneyard = deck.slice(14, 28);
  const opponentSeat = opponentSeatOf(previous);
  const starter = previousRoundWinner ?? determineOpeningSeat(hostHand, guestHand, opponentSeat);
  const starterLabel = starter === 'HOST' ? 'أنت (المضيف)' : previous.isVsBot ? 'الذكاء المحلي' : 'الضيف';

  return {
    ...previous,
    roundNumber: previous.roundNumber + 1,
    phase: 'PLAYING',
    board: [],
    leftEnd: null,
    rightEnd: null,
    hostHand,
    guestHand,
    boneyard,
    currentTurn: starter,
    consecutivePasses: 0,
    lastRoundSummary: null,
    lastActionArabic: `بدأت الجولة ${previous.roundNumber + 1} · يبدأ ${starterLabel}`,
  };
}

export function canPlayOnEnd(
  state: DominoGameState,
  tile: DominoTileData,
  end: BoardEnd
): boolean {
  if (state.board.length === 0) return true;
  const target = end === 'LEFT' ? state.leftEnd : state.rightEnd;
  if (target === null) return true;
  return tileMatches(tile, target);
}

export function legalMovesForSeat(state: DominoGameState, seat: PlayerSeat): LegalMove[] {
  if (state.phase !== 'PLAYING' || state.currentTurn !== seat) return [];
  const hand = handForSeat(state, seat);
  if (state.board.length === 0) {
    return hand.map((tile) => ({ tile, end: 'RIGHT' as const }));
  }
  const moves: LegalMove[] = [];
  for (const tile of hand) {
    if (canPlayOnEnd(state, tile, 'LEFT')) {
      moves.push({ tile, end: 'LEFT' });
    }
    if (canPlayOnEnd(state, tile, 'RIGHT')) {
      moves.push({ tile, end: 'RIGHT' });
    }
  }
  return moves;
}

export function playTile(
  state: DominoGameState,
  seat: PlayerSeat,
  tile: DominoTileData,
  end: BoardEnd
): DominoGameState | null {
  if (state.phase !== 'PLAYING' || state.currentTurn !== seat) return null;
  const hand = handForSeat(state, seat);
  const idx = hand.findIndex((t) => tileId(t) === tileId(tile));
  if (idx === -1) return null;

  const actual = hand[idx];
  let newBoard: PlacedTile[];
  let newLeft: number;
  let newRight: number;

  if (state.board.length === 0) {
    newBoard = [{ tile: actual, playedBy: seat }];
    newLeft = actual.left;
    newRight = actual.right;
  } else if (end === 'LEFT') {
    const leftTarget = state.leftEnd!;
    if (!tileMatches(actual, leftTarget)) return null;
    const oriented = actual.right === leftTarget ? actual : flipTile(actual);
    newBoard = [{ tile: oriented, playedBy: seat }, ...state.board];
    newLeft = oriented.left;
    newRight = state.rightEnd!;
  } else {
    const rightTarget = state.rightEnd!;
    if (!tileMatches(actual, rightTarget)) return null;
    const oriented = actual.left === rightTarget ? actual : flipTile(actual);
    newBoard = [...state.board, { tile: oriented, playedBy: seat }];
    newLeft = state.leftEnd!;
    newRight = oriented.right;
  }

  const updatedHand = hand.filter((_, i) => i !== idx);
  const nextTurn = seat === 'HOST' ? opponentSeatOf(state) : 'HOST';
  const seatArabic = seat === 'HOST' ? 'المضيف' : state.isVsBot ? 'الذكاء المحلي' : 'الضيف';

  const nextState: DominoGameState = {
    ...state,
    board: newBoard,
    leftEnd: newLeft,
    rightEnd: newRight,
    hostHand: seat === 'HOST' ? updatedHand : state.hostHand,
    guestHand: seat !== 'HOST' ? updatedHand : state.guestHand,
    currentTurn: nextTurn,
    consecutivePasses: 0,
    lastActionArabic: `وضع ${seatArabic} الحجر [${actual.left}|${actual.right}]`,
  };

  if (updatedHand.length === 0) {
    return finishRound(nextState, seat, 'DOMINO_OUT');
  }
  return nextState;
}

export function drawFromBoneyard(state: DominoGameState, seat: PlayerSeat): DominoGameState | null {
  if (state.phase !== 'PLAYING' || state.currentTurn !== seat) return null;
  if (state.boneyard.length === 0) return null;
  if (legalMovesForSeat(state, seat).length > 0) return null;

  const [drawn, ...rest] = state.boneyard;
  const seatArabic = seat === 'HOST' ? 'المضيف' : state.isVsBot ? 'الذكاء المحلي' : 'الضيف';

  return {
    ...state,
    hostHand: seat === 'HOST' ? [...state.hostHand, drawn] : state.hostHand,
    guestHand: seat !== 'HOST' ? [...state.guestHand, drawn] : state.guestHand,
    boneyard: rest,
    consecutivePasses: 0,
    lastActionArabic: `سحب ${seatArabic} حجراً من البنك (${rest.length} متبقٍ)`,
  };
}

export function passTurn(state: DominoGameState, seat: PlayerSeat): DominoGameState | null {
  if (state.phase !== 'PLAYING' || state.currentTurn !== seat) return null;
  if (legalMovesForSeat(state, seat).length > 0) return null;
  if (state.boneyard.length > 0) return null;

  const passes = state.consecutivePasses + 1;
  const nextTurn = seat === 'HOST' ? opponentSeatOf(state) : 'HOST';
  const seatArabic = seat === 'HOST' ? 'المضيف' : state.isVsBot ? 'الذكاء المحلي' : 'الضيف';

  const updated: DominoGameState = {
    ...state,
    currentTurn: nextTurn,
    consecutivePasses: passes,
    lastActionArabic: `مرّر ${seatArabic} الدور`,
  };

  if (passes >= 2) {
    const hostPips = updated.hostHand.reduce((acc, t) => acc + pipSum(t), 0);
    const guestPips = updated.guestHand.reduce((acc, t) => acc + pipSum(t), 0);
    const winner: PlayerSeat | null =
      hostPips < guestPips ? 'HOST' : guestPips < hostPips ? opponentSeatOf(updated) : null;
    return finishRound(updated, winner, 'BLOCKED_BOARD');
  }

  return updated;
}

function finishRound(
  state: DominoGameState,
  winner: PlayerSeat | null,
  reason: RoundEndReason
): DominoGameState {
  const hostPips = state.hostHand.reduce((acc, t) => acc + pipSum(t), 0);
  const guestPips = state.guestHand.reduce((acc, t) => acc + pipSum(t), 0);

  const pointsAwarded =
    winner === 'HOST' ? guestPips : winner !== null ? hostPips : 0;

  const newHostScore = state.hostScore + (winner === 'HOST' ? pointsAwarded : 0);
  const newGuestScore = state.guestScore + (winner !== null && winner !== 'HOST' ? pointsAwarded : 0);
  const matchOver = newHostScore >= state.targetScore || newGuestScore >= state.targetScore;

  const winnerLabel =
    winner === 'HOST' ? 'المضيف' : state.isVsBot ? 'الذكاء المحلي' : 'الضيف';

  const statusText =
    winner === null
      ? 'انغلقت الطاولة بالتعادل'
      : reason === 'DOMINO_OUT'
      ? `دومينو! فاز ${winnerLabel} بـ ${pointsAwarded} نقطة`
      : `انغلقت الطاولة · فاز ${winnerLabel} بـ ${pointsAwarded} نقطة`;

  return {
    ...state,
    phase: matchOver ? 'MATCH_OVER' : 'ROUND_OVER',
    hostScore: newHostScore,
    guestScore: newGuestScore,
    lastRoundSummary: {
      roundNumber: state.roundNumber,
      winner,
      reason,
      pointsAwarded,
      hostRemainingPips: hostPips,
      guestRemainingPips: guestPips,
    },
    lastActionArabic: statusText,
  };
}

export function chooseBotAction(
  state: DominoGameState
): { type: 'PLAY'; move: LegalMove } | { type: 'DRAW' } | { type: 'PASS' } {
  const moves = legalMovesForSeat(state, 'BOT');
  if (moves.length > 0) {
    const hand = state.guestHand;
    let best = moves[0];
    let bestScore = -Infinity;

    for (const move of moves) {
      const remaining = hand.filter((t) => tileId(t) !== tileId(move.tile));
      const newEnd =
        state.board.length === 0
          ? move.tile.right
          : move.end === 'LEFT'
          ? move.tile.right === state.leftEnd
            ? move.tile.left
            : move.tile.right
          : move.tile.left === state.rightEnd
          ? move.tile.right
          : move.tile.left;
      const support = remaining.filter((t) => tileMatches(t, newEnd)).length;
      const doubleBonus = isDouble(move.tile) ? 8 : 0;
      const score = pipSum(move.tile) * 2 + doubleBonus + support * 3;
      if (score > bestScore) {
        bestScore = score;
        best = move;
      }
    }
    return { type: 'PLAY', move: best };
  }

  return state.boneyard.length > 0 ? { type: 'DRAW' } : { type: 'PASS' };
}
