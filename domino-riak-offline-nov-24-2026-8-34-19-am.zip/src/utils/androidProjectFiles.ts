import JSZip from 'jszip';

export interface AndroidProjectFile {
  path: string;
  name: string;
  category: 'gradle' | 'manifest' | 'engine' | 'bluetooth' | 'ui' | 'resources';
  content: string;
}

const rawAndroidModules = import.meta.glob('/android/**/*', {
  query: '?raw',
  import: 'default',
  eager: true,
}) as Record<string, string>;

function classifyFile(relativePath: string): AndroidProjectFile['category'] {
  if (relativePath.includes('/engine/')) return 'engine';
  if (relativePath.includes('/bluetooth/')) return 'bluetooth';
  if (relativePath.includes('/ui/') || relativePath.endsWith('MainActivity.kt')) return 'ui';
  if (relativePath.includes('/res/') || relativePath.endsWith('AndroidManifest.xml')) {
    return relativePath.endsWith('AndroidManifest.xml') ? 'manifest' : 'resources';
  }
  return 'gradle';
}

export function getAndroidProjectFiles(): AndroidProjectFile[] {
  return Object.entries(rawAndroidModules)
    .map(([fullPath, content]) => {
      const cleanPath = fullPath.replace(/^\/android\//, '');
      const segments = cleanPath.split('/');
      return {
        path: cleanPath,
        name: segments[segments.length - 1],
        category: classifyFile(cleanPath),
        content,
      };
    })
    .sort((a, b) => a.path.localeCompare(b.path));
}

export async function downloadAndroidProjectZip(): Promise<void> {
  const files = getAndroidProjectFiles();
  const zip = new JSZip();
  const rootFolder = zip.folder('DominoRiakOffline');
  if (!rootFolder) return;

  for (const file of files) {
    rootFolder.file(file.path, file.content);
  }

  const blob = await zip.generateAsync({ type: 'blob' });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = 'DOMINO_RIAK_OFFLINE_Android.zip';
  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);
  URL.revokeObjectURL(url);
}
