import React, { useMemo, useState } from 'react';
import { Copy, Check, Download, FileCode2 } from 'lucide-react';
import {
  AndroidProjectFile,
  downloadAndroidProjectZip,
  getAndroidProjectFiles,
} from '../utils/androidProjectFiles';

type CategoryFilter = 'all' | AndroidProjectFile['category'];

const CATEGORY_LABELS: Record<CategoryFilter, string> = {
  all: 'كل الملفات',
  engine: 'محرك اللعبة',
  bluetooth: 'البلوتوث',
  ui: 'واجهات Compose',
  manifest: 'البيان',
  resources: 'الموارد العربية',
  gradle: 'إعداد Gradle',
};

export const AndroidCodeExplorer: React.FC = () => {
  const files = useMemo(() => getAndroidProjectFiles(), []);
  const [filter, setFilter] = useState<CategoryFilter>('all');
  const [selectedPath, setSelectedPath] = useState<string>(() => {
    const preferred = files.find((f) => f.path.endsWith('BluetoothController.kt'));
    return preferred?.path ?? files[0]?.path ?? '';
  });
  const [copied, setCopied] = useState(false);

  const filteredFiles = useMemo(
    () =>
      filter === 'all' ? files : files.filter((file) => file.category === filter),
    [files, filter]
  );

  const activeFile =
    files.find((f) => f.path === selectedPath) ?? filteredFiles[0] ?? null;

  const handleCopy = async () => {
    if (!activeFile) return;
    try {
      await navigator.clipboard.writeText(activeFile.content);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      // Clipboard fallback ignored if restricted
    }
  };

  return (
    <section className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#D4AF37]/20 pb-4">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-bold text-[#F0D27A]">
            مستكشف كود أندرويد الأصلي (Kotlin)
          </h1>
          <p className="text-sm text-[#A7B8B0] mt-1 tabular-nums">
            {files.length} ملف مصدر حقيقي جاهز للبناء في Android Studio · الحزمة com.riak.domino.offline
          </p>
        </div>

        <button
          type="button"
          onClick={() => downloadAndroidProjectZip()}
          className="inline-flex items-center gap-2 px-4 py-2 text-xs font-bold rounded-lg bg-[#D4AF37] text-[#070C0A] hover:bg-[#E6C453] transition-colors whitespace-nowrap shrink-0"
        >
          <Download className="w-4 h-4" />
          <span>تنزيل حزمة Android Studio (ZIP)</span>
        </button>
      </div>

      {/* Interactive Category Segmented Filter */}
      <div className="flex flex-wrap items-center gap-1.5 p-1.5 rounded-xl bg-[#081A14] border border-[#D4AF37]/20 w-fit">
        {(Object.keys(CATEGORY_LABELS) as CategoryFilter[]).map((cat) => (
          <button
            key={cat}
            type="button"
            onClick={() => setFilter(cat)}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 ${
              filter === cat
                ? 'bg-[#D4AF37] text-[#070C0A]'
                : 'text-[#A7B8B0] hover:text-[#F7F3E8]'
            }`}
          >
            {CATEGORY_LABELS[cat]}
          </button>
        ))}
      </div>

      {/* Split Explorer */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-stretch">
        <aside className="lg:col-span-4 rounded-xl border border-[#D4AF37]/25 bg-[#081510] p-3 space-y-1 max-h-[580px] overflow-y-auto">
          {filteredFiles.map((file) => {
            const isSelected = activeFile?.path === file.path;
            return (
              <button
                key={file.path}
                type="button"
                onClick={() => setSelectedPath(file.path)}
                className={`w-full text-right px-3 py-2.5 rounded-lg transition-colors flex items-center justify-between gap-2 ${
                  isSelected
                    ? 'bg-[#0B2E22] border border-[#D4AF37]/50 text-[#F0D27A]'
                    : 'text-[#DCE5DF] hover:bg-[#0B2018] border border-transparent'
                }`}
              >
                <div className="min-w-0">
                  <div className="text-sm font-semibold truncate">{file.name}</div>
                  <div dir="ltr" className="text-[11px] font-mono text-[#A7B8B0] truncate text-left">
                    {file.path}
                  </div>
                </div>
                <FileCode2 className="w-4 h-4 shrink-0 text-[#D4AF37]/75" />
              </button>
            );
          })}
        </aside>

        <div className="lg:col-span-8 rounded-xl border border-[#D4AF37]/25 bg-[#050C09] flex flex-col overflow-hidden">
          {activeFile ? (
            <>
              <div className="flex items-center justify-between gap-4 px-4 py-3 border-b border-[#D4AF37]/20 bg-[#081510]">
                <span dir="ltr" className="font-mono text-xs text-[#F0D27A] truncate">
                  android/{activeFile.path}
                </span>
                <button
                  type="button"
                  onClick={handleCopy}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-md border border-[#D4AF37]/30 text-[#F7F3E8] hover:border-[#D4AF37] transition-colors whitespace-nowrap shrink-0"
                >
                  {copied ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-[#D4AF37]" />
                      <span>تم النسخ</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5 text-[#D4AF37]" />
                      <span>نسخ الكود</span>
                    </>
                  )}
                </button>
              </div>
              <pre
                dir="ltr"
                className="flex-1 p-4 text-xs leading-relaxed font-mono text-[#E7EFEA] overflow-auto max-h-[520px] text-left"
              >
                <code>{activeFile.content}</code>
              </pre>
            </>
          ) : (
            <div className="p-8 text-center text-sm text-[#A7B8B0]">
              لا توجد ملفات مطابقة لهذا التصنيف.
            </div>
          )}
        </div>
      </div>
    </section>
  );
};
