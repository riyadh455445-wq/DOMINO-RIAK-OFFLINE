import React from 'react';
import type { DominoTileData } from '../engine/dominoEngine';

interface PipGridProps {
  value: number;
  size: 'sm' | 'md' | 'lg';
}

const PIP_POSITIONS: Record<number, number[]> = {
  0: [],
  1: [4],
  2: [0, 8],
  3: [0, 4, 8],
  4: [0, 2, 6, 8],
  5: [0, 2, 4, 6, 8],
  6: [0, 2, 3, 5, 6, 8],
};

const PipFace: React.FC<PipGridProps> = ({ value, size }) => {
  const active = PIP_POSITIONS[value] ?? [];
  const isAccent = value === 6 || value === 1;
  const dotSize =
    size === 'sm' ? 'w-1.5 h-1.5' : size === 'md' ? 'w-2 h-2' : 'w-2.5 h-2.5';

  return (
    <div className="grid grid-cols-3 grid-rows-3 place-items-center w-full h-full p-1.5">
      {Array.from({ length: 9 }).map((_, idx) => {
        const hasPip = active.includes(idx);
        return (
          <span
            key={idx}
            className={`rounded-full transition-transform ${dotSize} ${
              hasPip
                ? isAccent
                  ? 'bg-[#9E791E] shadow-inner'
                  : 'bg-[#101815] shadow-inner'
                : 'bg-transparent'
            }`}
          />
        );
      })}
    </div>
  );
};

interface DominoTileProps {
  tile: DominoTileData;
  orientation?: 'vertical' | 'horizontal';
  size?: 'sm' | 'md' | 'lg';
  playable?: boolean;
  selected?: boolean;
  disabled?: boolean;
  onClick?: () => void;
}

export const DominoTile: React.FC<DominoTileProps> = ({
  tile,
  orientation = 'vertical',
  size = 'md',
  playable = true,
  selected = false,
  disabled = false,
  onClick,
}) => {
  const isHorizontal = orientation === 'horizontal';

  const dimensions =
    size === 'sm'
      ? isHorizontal
        ? 'w-14 h-7'
        : 'w-7 h-14'
      : size === 'md'
      ? isHorizontal
        ? 'w-20 h-10'
        : 'w-10 h-20'
      : isHorizontal
      ? 'w-24 h-12'
      : 'w-12 h-24';

  const interactiveClasses = onClick
    ? playable
      ? 'cursor-pointer hover:-translate-y-1.5 active:translate-y-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#D4AF37]'
      : 'cursor-not-allowed opacity-45'
    : '';

  const borderClasses = selected
    ? 'border-2 border-[#F0D27A] ring-2 ring-[#D4AF37]/45 -translate-y-2 shadow-[0_10px_24px_rgba(212,175,55,0.28)]'
    : playable && onClick
    ? 'border border-[#D4AF37]/75 shadow-[0_6px_16px_rgba(0,0,0,0.45)]'
    : 'border border-[#D8CCB0] shadow-[0_4px_12px_rgba(0,0,0,0.4)]';

  const content = (
    <div
      dir="ltr"
      className={`relative flex ${
        isHorizontal ? 'flex-row' : 'flex-col'
      } ${dimensions} rounded-lg bg-gradient-to-b from-[#FCF9F0] to-[#EAE0C8] select-none transition-transform duration-150 ${borderClasses} ${interactiveClasses}`}
    >
      <div className="flex-1 min-w-0 min-h-0">
        <PipFace value={tile.left} size={size} />
      </div>
      <div
        className={
          isHorizontal
            ? 'w-[2px] my-1.5 bg-[#C9A33A]/85 rounded-full shrink-0'
            : 'h-[2px] mx-1.5 bg-[#C9A33A]/85 rounded-full shrink-0'
        }
      />
      <div className="flex-1 min-w-0 min-h-0">
        <PipFace value={tile.right} size={size} />
      </div>
    </div>
  );

  if (!onClick) {
    return content;
  }

  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled || !playable}
      aria-label={`حجر دومينو ${tile.left} و ${tile.right}`}
      className="bg-transparent p-0 border-0 shrink-0"
    >
      {content}
    </button>
  );
};

export const DominoBackTile: React.FC<{ compact?: boolean }> = ({ compact = false }) => (
  <div
    className={`${
      compact ? 'w-4 h-7' : 'w-6 h-10'
    } rounded bg-[#0A1310] border border-[#D4AF37]/55 shadow-sm flex items-center justify-center shrink-0`}
  >
    <div className="w-1.5 h-1.5 rotate-45 bg-[#D4AF37]/55" />
  </div>
);
