import React, { useEffect, useMemo, useState } from 'react';
import { Volume2, VolumeX, RotateCcw, BookOpen } from 'lucide-react';
import {
  BoardEnd,
  DominoGameState,
  DominoTileData,
  canPlayOnEnd,
  chooseBotAction,
  drawFromBoneyard,
  legalMovesForSeat,
  passTurn,
  playTile,
  startNewMatch,
  startRound,
  tileId,
} from '../engine/dominoEngine';
import { DominoBackTile, DominoTile } from './DominoTile';
import { playDrawSound, playRoundWinChime, playTileClack } from '../utils/soundFx';

export const PlayableTable: React.FC = () => {
  const [gameState, setGameState] = useState<DominoGameState>(() =>
    startNewMatch(101, true)
  );
  const [selectedTile, setSelectedTile] = useState<DominoTileData | null>(null);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [showRules, setShowRules] = useState(false);

  const isMyTurn = gameState.phase === 'PLAYING' && gameState.currentTurn === 'HOST';
  const myLegalMoves = useMemo(
    () => legalMovesForSeat(gameState, 'HOST'),
    [gameState]
  );

  // Automatic Bot Turn Loop
  useEffect(() => {
    if (
      gameState.phase !== 'PLAYING' ||
      !gameState.isVsBot ||
      gameState.currentTurn !== 'BOT'
    ) {
      return;
    }

    const timer = window.setTimeout(() => {
      const decision = chooseBotAction(gameState);
      let updated: DominoGameState | null = null;
      if (decision.type === 'PLAY') {
        updated = playTile(gameState, 'BOT', decision.move.tile, decision.move.end);
        if (updated) playTileClack(soundEnabled);
      } else if (decision.type === 'DRAW') {
        updated = drawFromBoneyard(gameState, 'BOT');
        if (updated) playDrawSound(soundEnabled);
      } else {
        updated = passTurn(gameState, 'BOT');
      }

      if (updated) {
        if (updated.phase === 'ROUND_OVER' || updated.phase === 'MATCH_OVER') {
          playRoundWinChime(soundEnabled);
        }
        setGameState(updated);
      }
    }, 680);

    return () => window.clearTimeout(timer);
  }, [gameState, soundEnabled]);

  const handleTileClick = (tile: DominoTileData) => {
    if (!isMyTurn) return;
    const canLeft = canPlayOnEnd(gameState, tile, 'LEFT');
    const canRight = canPlayOnEnd(gameState, tile, 'RIGHT');
    if (!canLeft && !canRight) return;

    if (gameState.board.length === 0) {
      executePlayerMove(tile, 'RIGHT');
      return;
    }
    if (canLeft && !canRight) {
      executePlayerMove(tile, 'LEFT');
      return;
    }
    if (canRight && !canLeft) {
      executePlayerMove(tile, 'RIGHT');
      return;
    }

    setSelectedTile((prev) =>
      prev && tileId(prev) === tileId(tile) ? null : tile
    );
  };

  const executePlayerMove = (tile: DominoTileData, end: BoardEnd) => {
    const updated = playTile(gameState, 'HOST', tile, end);
    if (!updated) return;
    playTileClack(soundEnabled);
    if (updated.phase === 'ROUND_OVER' || updated.phase === 'MATCH_OVER') {
      playRoundWinChime(soundEnabled);
    }
    setSelectedTile(null);
    setGameState(updated);
  };

  const handleDraw = () => {
    const updated = drawFromBoneyard(gameState, 'HOST');
    if (!updated) return;
    playDrawSound(soundEnabled);
    setGameState(updated);
  };

  const handlePass = () => {
    const updated = passTurn(gameState, 'HOST');
    if (!updated) return;
    if (updated.phase === 'ROUND_OVER' || updated.phase === 'MATCH_OVER') {
      playRoundWinChime(soundEnabled);
    }
    setGameState(updated);
  };

  const handleNextRound = () => {
    const winner = gameState.lastRoundSummary?.winner ?? null;
    setSelectedTile(null);
    setGameState((prev) => startRound(prev, winner));
  };

  const handleRestartMatch = () => {
    setSelectedTile(null);
    setGameState(startNewMatch(101, true));
  };

  return (
    <section className="space-y-6">
      {/* Compact Score & Action Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#D4AF37]/20 pb-4">
        <div className="space-y-1">
          <h1 className="font-display text-2xl sm:text-3xl font-bold text-[#F0D27A]">
            طاولة دومينو رياك أوفلاين
          </h1>
          <div className="flex flex-wrap items-center gap-2 text-sm text-[#A7B8B0] tabular-nums">
            <span>الجولة {gameState.roundNumber}</span>
            <span aria-hidden="true">·</span>
            <span>نقاطك: {gameState.hostScore}</span>
            <span aria-hidden="true">·</span>
            <span>الذكاء المحلي: {gameState.guestScore}</span>
            <span aria-hidden="true">·</span>
            <span>الهدف: {gameState.targetScore}</span>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => setSoundEnabled((v) => !v)}
            className="inline-flex items-center gap-2 px-3 py-2 text-xs font-semibold rounded-lg border border-[#D4AF37]/30 bg-[#0B2018] text-[#F7F3E8] hover:border-[#D4AF37] transition-colors whitespace-nowrap shrink-0"
          >
            {soundEnabled ? <Volume2 className="w-4 h-4 text-[#D4AF37]" /> : <VolumeX className="w-4 h-4 text-[#A7B8B0]" />}
            <span>{soundEnabled ? 'الصوت مفعّل' : 'صامت'}</span>
          </button>

          <button
            type="button"
            onClick={() => setShowRules((v) => !v)}
            className="inline-flex items-center gap-2 px-3 py-2 text-xs font-semibold rounded-lg border border-[#D4AF37]/30 bg-[#0B2018] text-[#F7F3E8] hover:border-[#D4AF37] transition-colors whitespace-nowrap shrink-0"
          >
            <BookOpen className="w-4 h-4 text-[#D4AF37]" />
            <span>القواعد</span>
          </button>

          <button
            type="button"
            onClick={handleRestartMatch}
            className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-bold rounded-lg bg-[#D4AF37] text-[#070C0A] hover:bg-[#E6C453] transition-colors whitespace-nowrap shrink-0"
          >
            <RotateCcw className="w-4 h-4" />
            <span>مباراة جديدة</span>
          </button>
        </div>
      </div>

      {showRules && (
        <div className="rounded-xl border border-[#D4AF37]/30 bg-[#0B2018] p-5 text-sm text-[#DCE5DF] leading-relaxed space-y-2">
          <p className="font-bold text-[#F0D27A]">قواعد اللعب القياسية (Double-Six · 101 نقطة)</p>
          <p>
            يحصل كل لاعب على 7 أحجار وتبقى 14 في البنك. في كل دور، ضع حجراً يطابق أحد طرفي السلسلة على الطاولة. عند عدم توفر حجر مناسب، اسحب من البنك حتى تجد حجراً مطابقاً أو ينفد البنك فتمرّر الدور. عند نفاد أحجار لاعب أو إغلاق الطاولة، يُضاف مجموع نقاط يد الخاسر إلى رصيد الفائز.
          </p>
        </div>
      )}

      {/* Main Emerald Felt Tabletop */}
      <div className="relative rounded-2xl border border-[#D4AF37]/40 bg-[#05291E] overflow-hidden shadow-[0_24px_60px_rgba(0,0,0,0.65)]">
        <img
          src="/src/assets/images/emerald_felt_table_1795505426166.jpg"
          alt="سطح طاولة الدومينو الزمردي"
          referrerPolicy="no-referrer"
          className="absolute inset-0 w-full h-full object-cover opacity-25 pointer-events-none select-none"
        />

        <div className="relative z-10 p-5 sm:p-7 space-y-6">
          {/* Opponent Hand & Turn Status */}
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <span className="text-sm font-semibold text-[#F7F3E8]">الذكاء المحلي</span>
              <span className="text-xs text-[#A7B8B0] tabular-nums">
                ({gameState.guestHand.length} أحجار)
              </span>
              <div className="flex items-center gap-1.5 mr-2">
                {gameState.guestHand.map((_, idx) => (
                  <DominoBackTile key={idx} compact />
                ))}
              </div>
            </div>

            <div className="text-sm font-bold text-[#F0D27A]">
              {gameState.phase === 'PLAYING'
                ? isMyTurn
                  ? 'دورك الآن — اختر حجراً من يدك'
                  : 'يفكر الخصم في حركته…'
                : gameState.lastActionArabic}
            </div>
          </div>

          {/* Center Domino Chain */}
          <div
            dir="ltr"
            className="min-h-[210px] rounded-xl border border-[#D4AF37]/25 bg-[#042118]/80 p-5 flex items-center justify-center"
          >
            {gameState.board.length === 0 ? (
              <p dir="rtl" className="text-sm text-[#A7B8B0]">
                الطاولة فارغة الآن — ابدأ بوضع أول حجر من يدك
              </p>
            ) : (
              <div className="flex flex-wrap items-center justify-center gap-1.5 max-w-4xl">
                {gameState.board.map((placed, idx) => {
                  const dbl = placed.tile.left === placed.tile.right;
                  return (
                    <DominoTile
                      key={`${tileId(placed.tile)}-${idx}`}
                      tile={placed.tile}
                      orientation={dbl ? 'vertical' : 'horizontal'}
                      size="md"
                      playable
                    />
                  );
                })}
              </div>
            )}
          </div>

          {/* Ambiguity Choice or Draw / Pass Controls */}
          <div className="flex flex-wrap items-center justify-between gap-4 border-t border-[#D4AF37]/20 pt-4">
            <div className="text-sm text-[#DCE5DF] tabular-nums">
              <span>{gameState.lastActionArabic}</span>
              <span className="mx-2 text-[#D4AF37]/60" aria-hidden="true">·</span>
              <span>البنك: {gameState.boneyard.length}</span>
              {gameState.leftEnd !== null && gameState.rightEnd !== null && (
                <>
                  <span className="mx-2 text-[#D4AF37]/60" aria-hidden="true">·</span>
                  <span>
                    الأطراف المفتوحة: {gameState.leftEnd} / {gameState.rightEnd}
                  </span>
                </>
              )}
            </div>

            <div className="flex items-center gap-3">
              {selectedTile && isMyTurn && gameState.board.length > 0 && (
                <>
                  <button
                    type="button"
                    onClick={() => executePlayerMove(selectedTile, 'LEFT')}
                    className="px-4 py-2 text-xs font-bold rounded-lg bg-[#D4AF37] text-[#070C0A] hover:bg-[#E6C453] transition-colors whitespace-nowrap shrink-0"
                  >
                    وضع على الطرف ({gameState.leftEnd})
                  </button>
                  <button
                    type="button"
                    onClick={() => executePlayerMove(selectedTile, 'RIGHT')}
                    className="px-4 py-2 text-xs font-bold rounded-lg bg-[#D4AF37] text-[#070C0A] hover:bg-[#E6C453] transition-colors whitespace-nowrap shrink-0"
                  >
                    وضع على الطرف ({gameState.rightEnd})
                  </button>
                </>
              )}

              {isMyTurn && myLegalMoves.length === 0 && (
                gameState.boneyard.length > 0 ? (
                  <button
                    type="button"
                    onClick={handleDraw}
                    className="px-4 py-2 text-xs font-bold rounded-lg bg-[#D4AF37] text-[#070C0A] hover:bg-[#E6C453] transition-colors whitespace-nowrap shrink-0"
                  >
                    سحب حجر من البنك ({gameState.boneyard.length})
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={handlePass}
                    className="px-4 py-2 text-xs font-bold rounded-lg border border-[#D4AF37] text-[#F0D27A] hover:bg-[#D4AF37]/15 transition-colors whitespace-nowrap shrink-0"
                  >
                    تمرير الدور
                  </button>
                )
              )}
            </div>
          </div>

          {/* Player Hand */}
          <div className="rounded-xl bg-[#071510]/85 border border-[#D4AF37]/20 p-4">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-semibold text-[#A7B8B0]">
                يدك ({gameState.hostHand.length} أحجار)
              </span>
              {selectedTile && (
                <span className="text-xs text-[#F0D27A]">
                  الحجر المحدد [{selectedTile.left}|{selectedTile.right}] يصلح للطرفين — اختر الطرف أعلاه
                </span>
              )}
            </div>
            <div className="flex flex-wrap items-center justify-center gap-3 min-h-[104px]">
              {gameState.hostHand.map((tile) => {
                const playable =
                  isMyTurn &&
                  myLegalMoves.some((m) => tileId(m.tile) === tileId(tile));
                const isSelected =
                  selectedTile !== null && tileId(selectedTile) === tileId(tile);

                return (
                  <DominoTile
                    key={tileId(tile)}
                    tile={tile}
                    orientation="vertical"
                    size="lg"
                    playable={playable}
                    selected={isSelected}
                    disabled={!isMyTurn}
                    onClick={() => handleTileClick(tile)}
                  />
                );
              })}
            </div>
          </div>
        </div>

        {/* Round / Match End Overlay */}
        {(gameState.phase === 'ROUND_OVER' || gameState.phase === 'MATCH_OVER') &&
          gameState.lastRoundSummary && (
            <div className="absolute inset-0 z-20 bg-[#050A08]/85 backdrop-blur-sm flex items-center justify-center p-6">
              <div className="w-full max-w-md rounded-2xl border border-[#D4AF37] bg-[#0B2018] p-6 text-center space-y-4 shadow-2xl">
                <h2 className="font-display text-2xl font-bold text-[#F0D27A]">
                  {gameState.phase === 'MATCH_OVER'
                    ? gameState.hostScore >= gameState.targetScore
                      ? 'مبروك! فزت بالمباراة'
                      : 'انتهت المباراة لصالح الخصم'
                    : `نهاية الجولة ${gameState.lastRoundSummary.roundNumber}`}
                </h2>
                <p className="text-sm text-[#F7F3E8]">{gameState.lastActionArabic}</p>
                <div className="grid grid-cols-2 gap-3 py-2 border-y border-[#D4AF37]/20 text-sm tabular-nums">
                  <div>
                    <div className="text-[#A7B8B0] text-xs">رصيدك الإجمالي</div>
                    <div className="text-lg font-bold text-[#F0D27A]">{gameState.hostScore}</div>
                  </div>
                  <div>
                    <div className="text-[#A7B8B0] text-xs">رصيد الخصم</div>
                    <div className="text-lg font-bold text-[#F7F3E8]">{gameState.guestScore}</div>
                  </div>
                </div>
                <div className="flex items-center justify-center gap-3 pt-1">
                  {gameState.phase === 'ROUND_OVER' ? (
                    <button
                      type="button"
                      onClick={handleNextRound}
                      className="px-5 py-2.5 text-sm font-bold rounded-lg bg-[#D4AF37] text-[#070C0A] hover:bg-[#E6C453] transition-colors whitespace-nowrap"
                    >
                      بدء الجولة التالية
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={handleRestartMatch}
                      className="px-5 py-2.5 text-sm font-bold rounded-lg bg-[#D4AF37] text-[#070C0A] hover:bg-[#E6C453] transition-colors whitespace-nowrap"
                    >
                      لعب مجدداً
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}
      </div>
    </section>
  );
};
