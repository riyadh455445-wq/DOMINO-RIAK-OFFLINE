import React, { useState } from 'react';
import { Bluetooth, RotateCcw } from 'lucide-react';
import {
  BoardEnd,
  DominoGameState,
  DominoTileData,
  PlayerSeat,
  canPlayOnEnd,
  drawFromBoneyard,
  legalMovesForSeat,
  passTurn,
  playTile,
  startNewMatch,
  startRound,
  tileId,
} from '../engine/dominoEngine';
import { DominoBackTile, DominoTile } from './DominoTile';
import { playDrawSound, playRoundWinChime, playTileClack } from '../utils/soundFx';

interface PacketLogItem {
  id: number;
  direction: 'HOST → GUEST' | 'GUEST → HOST';
  packetType: string;
  payloadSummary: string;
}

export const DualBluetoothSim: React.FC = () => {
  const [state, setState] = useState<DominoGameState>(() => startNewMatch(101, false));
  const [hostSelected, setHostSelected] = useState<DominoTileData | null>(null);
  const [guestSelected, setGuestSelected] = useState<DominoTileData | null>(null);
  const [packets, setPackets] = useState<PacketLogItem[]>([
    {
      id: 1,
      direction: 'HOST → GUEST',
      packetType: 'state_sync',
      payloadSummary: 'توزيع 7 أحجار لكل جهاز عبر قناة RFCOMM (UUID: 8a4d2c9e…)',
    },
  ]);

  const appendPacket = (
    direction: PacketLogItem['direction'],
    packetType: string,
    payloadSummary: string
  ) => {
    setPackets((prev) => [
      { id: Date.now() + Math.random(), direction, packetType, payloadSummary },
      ...prev.slice(0, 7),
    ]);
  };

  const handleSeatTileClick = (seat: PlayerSeat, tile: DominoTileData) => {
    if (state.phase !== 'PLAYING' || state.currentTurn !== seat) return;
    const canLeft = canPlayOnEnd(state, tile, 'LEFT');
    const canRight = canPlayOnEnd(state, tile, 'RIGHT');
    if (!canLeft && !canRight) return;

    if (state.board.length === 0) {
      executeMove(seat, tile, 'RIGHT');
      return;
    }
    if (canLeft && !canRight) {
      executeMove(seat, tile, 'LEFT');
      return;
    }
    if (canRight && !canLeft) {
      executeMove(seat, tile, 'RIGHT');
      return;
    }

    if (seat === 'HOST') {
      setHostSelected((p) => (p && tileId(p) === tileId(tile) ? null : tile));
    } else {
      setGuestSelected((p) => (p && tileId(p) === tileId(tile) ? null : tile));
    }
  };

  const executeMove = (seat: PlayerSeat, tile: DominoTileData, end: BoardEnd) => {
    const updated = playTile(state, seat, tile, end);
    if (!updated) return;
    playTileClack(true);
    if (updated.phase !== 'PLAYING') playRoundWinChime(true);

    setHostSelected(null);
    setGuestSelected(null);
    setState(updated);

    if (seat === 'GUEST') {
      appendPacket(
        'GUEST → HOST',
        'play_tile',
        `{"tile":[${tile.left},${tile.right}],"end":"${end}"}`
      );
    }
    appendPacket(
      'HOST → GUEST',
      'state_sync',
      `تحديث الطاولة · الدور الآن: ${updated.currentTurn} · البنك: ${updated.boneyard.length}`
    );
  };

  const handleDraw = (seat: PlayerSeat) => {
    const updated = drawFromBoneyard(state, seat);
    if (!updated) return;
    playDrawSound(true);
    setState(updated);
    if (seat === 'GUEST') {
      appendPacket('GUEST → HOST', 'draw_tile', '{"type":"draw_tile"}');
    }
    appendPacket(
      'HOST → GUEST',
      'state_sync',
      `سحب حجر · المتبقي في البنك: ${updated.boneyard.length}`
    );
  };

  const handlePass = (seat: PlayerSeat) => {
    const updated = passTurn(state, seat);
    if (!updated) return;
    setState(updated);
    if (seat === 'GUEST') {
      appendPacket('GUEST → HOST', 'pass_turn', '{"type":"pass_turn"}');
    }
    appendPacket('HOST → GUEST', 'state_sync', `تمرير الدور إلى ${updated.currentTurn}`);
  };

  const handleReset = () => {
    const fresh = startNewMatch(101, false);
    setHostSelected(null);
    setGuestSelected(null);
    setState(fresh);
    setPackets([
      {
        id: Date.now(),
        direction: 'HOST → GUEST',
        packetType: 'state_sync',
        payloadSummary: 'بدء جلسة بلوتوث جديدة بين جهاز المضيف وجهاز الضيف',
      },
    ]);
  };

  const handleNextRound = () => {
    const next = startRound(state, state.lastRoundSummary?.winner ?? null);
    setHostSelected(null);
    setGuestSelected(null);
    setState(next);
    appendPacket('HOST → GUEST', 'state_sync', `بدء الجولة ${next.roundNumber}`);
  };

  const renderDevicePanel = (
    seat: 'HOST' | 'GUEST',
    title: string,
    subtitle: string,
    hand: DominoTileData[],
    oppCount: number,
    selected: DominoTileData | null
  ) => {
    const isTurn = state.phase === 'PLAYING' && state.currentTurn === seat;
    const moves = legalMovesForSeat(state, seat);

    return (
      <div
        className={`rounded-2xl border p-4 space-y-4 transition-colors ${
          isTurn
            ? 'border-[#D4AF37] bg-[#062E22]'
            : 'border-[#D4AF37]/25 bg-[#081A14]'
        }`}
      >
        <div className="flex items-center justify-between border-b border-[#D4AF37]/15 pb-3">
          <div>
            <h3 className="font-bold text-base text-[#F0D27A]">{title}</h3>
            <p className="text-xs text-[#A7B8B0]">{subtitle}</p>
          </div>
          <span
            className={`text-xs font-bold ${
              isTurn ? 'text-[#F0D27A]' : 'text-[#A7B8B0]'
            }`}
          >
            {isTurn ? 'دوره الآن' : 'بانتظار الخصم'}
          </span>
        </div>

        <div className="flex items-center justify-between text-xs text-[#A7B8B0] tabular-nums">
          <span>النقاط: {seat === 'HOST' ? state.hostScore : state.guestScore}</span>
          <div className="flex items-center gap-1">
            <span>الخصم ({oppCount}):</span>
            {Array.from({ length: Math.min(oppCount, 7) }).map((_, i) => (
              <DominoBackTile key={i} compact />
            ))}
          </div>
        </div>

        <div
          dir="ltr"
          className="min-h-[110px] rounded-xl bg-[#041B14] border border-[#D4AF37]/20 p-3 flex flex-wrap items-center justify-center gap-1"
        >
          {state.board.length === 0 ? (
            <span dir="rtl" className="text-xs text-[#A7B8B0]">
              بانتظار أول حجر…
            </span>
          ) : (
            state.board.map((placed, idx) => (
              <DominoTile
                key={`${seat}-${idx}`}
                tile={placed.tile}
                orientation={placed.tile.left === placed.tile.right ? 'vertical' : 'horizontal'}
                size="sm"
              />
            ))
          )}
        </div>

        {selected && isTurn && state.board.length > 0 && (
          <div className="flex items-center justify-center gap-2">
            <button
              type="button"
              onClick={() => executeMove(seat, selected, 'LEFT')}
              className="px-3 py-1.5 text-xs font-bold rounded-md bg-[#D4AF37] text-[#070C0A]"
            >
              يسار ({state.leftEnd})
            </button>
            <button
              type="button"
              onClick={() => executeMove(seat, selected, 'RIGHT')}
              className="px-3 py-1.5 text-xs font-bold rounded-md bg-[#D4AF37] text-[#070C0A]"
            >
              يمين ({state.rightEnd})
            </button>
          </div>
        )}

        {isTurn && moves.length === 0 && (
          <div className="flex justify-center">
            {state.boneyard.length > 0 ? (
              <button
                type="button"
                onClick={() => handleDraw(seat)}
                className="px-4 py-1.5 text-xs font-bold rounded-lg bg-[#D4AF37] text-[#070C0A]"
              >
                سحب من البنك ({state.boneyard.length})
              </button>
            ) : (
              <button
                type="button"
                onClick={() => handlePass(seat)}
                className="px-4 py-1.5 text-xs font-bold rounded-lg border border-[#D4AF37] text-[#F0D27A]"
              >
                تمرير الدور
              </button>
            )}
          </div>
        )}

        <div className="flex flex-wrap items-center justify-center gap-2 pt-1">
          {hand.map((t) => {
            const playable = isTurn && moves.some((m) => tileId(m.tile) === tileId(t));
            const isSel = selected !== null && tileId(selected) === tileId(t);
            return (
              <DominoTile
                key={`${seat}-${tileId(t)}`}
                tile={t}
                size="sm"
                playable={playable}
                selected={isSel}
                disabled={!isTurn}
                onClick={() => handleSeatTileClick(seat, t)}
              />
            );
          })}
        </div>
      </div>
    );
  };

  return (
    <section className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#D4AF37]/20 pb-4">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-bold text-[#F0D27A]">
            محاكاة الاتصال الثنائي عبر البلوتوث (RFCOMM)
          </h1>
          <p className="text-sm text-[#A7B8B0] mt-1">
            جرّب اللعب بين جهاز المضيف وجهاز الضيف وشاهد تبادل حزم BluetoothPacket اللحظي.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {state.phase === 'ROUND_OVER' && (
            <button
              type="button"
              onClick={handleNextRound}
              className="px-4 py-2 text-xs font-bold rounded-lg bg-[#D4AF37] text-[#070C0A]"
            >
              بدء الجولة التالية
            </button>
          )}
          <button
            type="button"
            onClick={handleReset}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-bold rounded-lg border border-[#D4AF37]/40 text-[#F0D27A] hover:border-[#D4AF37]"
          >
            <RotateCcw className="w-4 h-4" />
            <span>إعادة ضبط الجلسة</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {renderDevicePanel(
          'HOST',
          'الجهاز الأول · المضيف (Host)',
          'BluetoothServerSocket · يدير محرك القواعد ويُرسل StateSync',
          state.hostHand,
          state.guestHand.length,
          hostSelected
        )}
        {renderDevicePanel(
          'GUEST',
          'الجهاز الثاني · الضيف (Guest)',
          'BluetoothSocket · يرسل PlayTile / DrawTile ويستقبل StateSync',
          state.guestHand,
          state.hostHand.length,
          guestSelected
        )}
      </div>

      <div className="rounded-xl border border-[#D4AF37]/25 bg-[#081510] p-4 space-y-3">
        <div className="flex items-center gap-2 text-sm font-bold text-[#F0D27A]">
          <Bluetooth className="w-4 h-4" />
          <span>سجل حزم بروتوكول البلوتوث (BluetoothProtocol.kt)</span>
        </div>
        <div className="space-y-2 max-h-52 overflow-y-auto">
          {packets.map((pkt) => (
            <div
              key={pkt.id}
              className="flex flex-wrap items-center justify-between gap-2 text-xs border-b border-[#D4AF37]/10 pb-2"
            >
              <div className="flex items-center gap-2">
                <span dir="ltr" className="font-mono text-[#D4AF37]">
                  {pkt.direction}
                </span>
                <span aria-hidden="true">·</span>
                <span dir="ltr" className="font-mono text-[#F7F3E8]">
                  {pkt.packetType}
                </span>
              </div>
              <span className="text-[#A7B8B0] font-mono text-[11px]">{pkt.payloadSummary}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
