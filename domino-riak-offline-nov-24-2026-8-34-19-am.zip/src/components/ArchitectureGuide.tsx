import React from 'react';
import { Download } from 'lucide-react';
import { downloadAndroidProjectZip } from '../utils/androidProjectFiles';

export const ArchitectureGuide: React.FC = () => {
  return (
    <section className="space-y-8">
      {/* Hero Overview Split */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch border-b border-[#D4AF37]/20 pb-8">
        <div className="lg:col-span-8 flex flex-col justify-center space-y-4">
          <div className="text-xs text-[#D4AF37] font-semibold">
            DOMINO RIAK OFFLINE · تطبيق أندرويد أصلي بلغة Kotlin · تطوير RIAK
          </div>
          <h1 className="font-display text-3xl sm:text-4xl font-bold text-[#F7F3E8] leading-snug">
            معمارية اللعب الجماعي أوفلاين عبر البلوتوث المباشر
          </h1>
          <p className="text-base text-[#B6C5BD] leading-relaxed max-w-2xl">
            تم تصميم تطبيق دومينو رياك أوفلاين ليعمل بشكل أصلي بالكامل على هواتف أندرويد (API 26–35) باستخدام Classic Bluetooth RFCOMM وواجهات Jetpack Compose الداعمة للغة العربية (RTL) من اليمين إلى اليسار دون أي اعتماد على خوادم أو اتصال بالإنترنت.
          </p>
          <div className="pt-2">
            <button
              type="button"
              onClick={() => downloadAndroidProjectZip()}
              className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-bold rounded-lg bg-[#D4AF37] text-[#070C0A] hover:bg-[#E6C453] transition-colors"
            >
              <Download className="w-4 h-4" />
              <span>تنزيل مشروع Android Studio الكامل (ZIP)</span>
            </button>
          </div>
        </div>

        <div className="lg:col-span-4 rounded-2xl border border-[#D4AF37]/35 bg-[#081510] overflow-hidden flex items-center justify-center p-4">
          <img
            src="/src/assets/images/domino_riak_emblem_1795505425176.jpg"
            alt="شعار دومينو رياك أوفلاين"
            referrerPolicy="no-referrer"
            className="w-full max-w-[260px] aspect-square object-cover rounded-xl"
          />
        </div>
      </div>

      {/* 4 Core Architectural Layers */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <article className="rounded-xl border border-[#D4AF37]/25 bg-[#081913] p-6 space-y-2">
          <div className="text-xs font-semibold text-[#D4AF37]">01. محرك القواعد الصرف</div>
          <h2 className="font-display text-xl font-bold text-[#F7F3E8]">
            DominoEngine &amp; DominoModels
          </h2>
          <p className="text-sm text-[#B6C5BD] leading-relaxed">
            منطق لعبة الدومينو القياسي (28 حجراً · Double-Six) مكتوب بـ Kotlin النقية دون تبعيات واجهة: توزيع 7 أحجار، تحديد البادئ بأعلى دبل، التحقق من تطابق الطرفين الأيمن والأيسر، السحب من البنك، التمرير، كشف إغلاق الطاولة، وحساب النقاط حتى 101 نقطة.
          </p>
        </article>

        <article className="rounded-xl border border-[#D4AF37]/25 bg-[#081913] p-6 space-y-2">
          <div className="text-xs font-semibold text-[#D4AF37]">02. طبقة البلوتوث الأصلية</div>
          <h2 className="font-display text-xl font-bold text-[#F7F3E8]">
            BluetoothController (Classic RFCOMM)
          </h2>
          <p className="text-sm text-[#B6C5BD] leading-relaxed">
            يدير قناة RFCOMM عبر معرف خدمة مخصص (UUID) باستخدام BluetoothServerSocket لجهاز المضيف وBluetoothSocket لجهاز الضيف، مع دعم اكتشاف الأجهزة القريبة (ACTION_FOUND) والأجهزة المقترنة وتدفقات Coroutines StateFlow.
          </p>
        </article>

        <article className="rounded-xl border border-[#D4AF37]/25 bg-[#081913] p-6 space-y-2">
          <div className="text-xs font-semibold text-[#D4AF37]">03. بروتوكول المزامنة الموثوق</div>
          <h2 className="font-display text-xl font-bold text-[#F7F3E8]">
            BluetoothProtocol (Host-Authoritative)
          </h2>
          <p className="text-sm text-[#B6C5BD] leading-relaxed">
            يعتمد نموذج المضيف المرجعي لمنع أي تضارب في الحالة: يرسل الضيف أوامر اللعب والسحب والتمرير عبر kotlinx.serialization، فيتحقق المضيف من قانونيتها ويعيد بث StateSync موحد لكلا الجهازين.
          </p>
        </article>

        <article className="rounded-xl border border-[#D4AF37]/25 bg-[#081913] p-6 space-y-2">
          <div className="text-xs font-semibold text-[#D4AF37]">04. واجهة Jetpack Compose العربية</div>
          <h2 className="font-display text-xl font-bold text-[#F7F3E8]">
            RTL Emerald, Gold &amp; Ivory Canvas
          </h2>
          <p className="text-sm text-[#B6C5BD] leading-relaxed">
            رسم مخصص لأحجار الدومينو العاجية بفاصل ذهبي ونقاط داكنة عبر Compose Canvas، مع فرض LayoutDirection.Rtl بالكامل، ودعم شاشات Android 12+ لصلاحيات البلوتوث، ووضع تدريب فردي ضد DominoBot.
          </p>
        </article>
      </div>

      {/* Permissions & Android Studio Checklist */}
      <div className="rounded-xl border border-[#D4AF37]/25 bg-[#081510] p-6 space-y-4">
        <h2 className="font-display text-xl font-bold text-[#F0D27A]">
          صلاحيات البلوتوث وخطوات التشغيل على جهازين حقيقيين
        </h2>
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-right border-collapse">
            <thead>
              <tr className="border-b border-[#D4AF37]/25 text-[#F0D27A]">
                <th className="py-2.5 pl-4 font-semibold">إصدار أندرويد</th>
                <th className="py-2.5 pl-4 font-semibold">الصلاحيات المطلوبة في Manifest</th>
                <th className="py-2.5 font-semibold">الغرض التشغيلي</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#D4AF37]/10 text-[#DCE5DF]">
              <tr>
                <td className="py-2.5 pl-4 tabular-nums">Android 12+ (API 31–35)</td>
                <td dir="ltr" className="py-2.5 pl-4 font-mono text-xs text-left">
                  BLUETOOTH_SCAN, BLUETOOTH_CONNECT, BLUETOOTH_ADVERTISE
                </td>
                <td className="py-2.5">البحث عن الأجهزة، فتح مقبس RFCOMM، وجعل الجهاز مرئياً دون إذن الموقع</td>
              </tr>
              <tr>
                <td className="py-2.5 pl-4 tabular-nums">Android 8–11 (API 26–30)</td>
                <td dir="ltr" className="py-2.5 pl-4 font-mono text-xs text-left">
                  BLUETOOTH, BLUETOOTH_ADMIN, ACCESS_FINE_LOCATION
                </td>
                <td className="py-2.5">اكتشاف الأجهزة القريبة وتأسيس اتصال البلوتوث التقليدي</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
};
