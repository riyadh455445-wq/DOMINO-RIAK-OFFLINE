import { useState } from 'react';
import { Download } from 'lucide-react';
import { PlayableTable } from './components/PlayableTable';
import { DualBluetoothSim } from './components/DualBluetoothSim';
import { AndroidCodeExplorer } from './components/AndroidCodeExplorer';
import { ArchitectureGuide } from './components/ArchitectureGuide';
import { downloadAndroidProjectZip } from './utils/androidProjectFiles';

type ActiveSection = 'play' | 'bluetooth' | 'code' | 'architecture';

export default function App() {
  const [activeSection, setActiveSection] = useState<ActiveSection>('play');
  const [exporting, setExporting] = useState(false);

  const handleExportZip = async () => {
    setExporting(true);
    try {
      await downloadAndroidProjectZip();
    } finally {
      setExporting(false);
    }
  };

  return (
    <div dir="rtl" className="min-h-screen bg-[#06110D] text-[#F7F3E8] flex flex-col">
      {/* Strict 3-Zone Top Bar Contract */}
      <header className="sticky top-0 z-30 bg-[#06110D]/95 backdrop-blur-md border-b border-[#D4AF37]/20">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between gap-8">
          {/* Zone 1: Single-line Brand Wordmark */}
          <button
            type="button"
            onClick={() => setActiveSection('play')}
            className="font-display text-xl font-bold text-[#F0D27A] tracking-tight whitespace-nowrap shrink-0 bg-transparent border-0 p-0 cursor-pointer"
          >
            دومينو رياك
          </button>

          {/* Zone 2: Clean single-line nav links */}
          <nav className="flex items-center gap-6 overflow-x-auto">
            <button
              type="button"
              onClick={() => setActiveSection('play')}
              className={`text-sm font-semibold pb-1 border-b-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activeSection === 'play'
                  ? 'border-[#D4AF37] text-[#F0D27A]'
                  : 'border-transparent text-[#A7B8B0] hover:text-[#F7F3E8]'
              }`}
            >
              طاولة اللعب
            </button>
            <button
              type="button"
              onClick={() => setActiveSection('bluetooth')}
              className={`text-sm font-semibold pb-1 border-b-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activeSection === 'bluetooth'
                  ? 'border-[#D4AF37] text-[#F0D27A]'
                  : 'border-transparent text-[#A7B8B0] hover:text-[#F7F3E8]'
              }`}
            >
              جهازَي البلوتوث
            </button>
            <button
              type="button"
              onClick={() => setActiveSection('code')}
              className={`text-sm font-semibold pb-1 border-b-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activeSection === 'code'
                  ? 'border-[#D4AF37] text-[#F0D27A]'
                  : 'border-transparent text-[#A7B8B0] hover:text-[#F7F3E8]'
              }`}
            >
              كود أندرويد
            </button>
            <button
              type="button"
              onClick={() => setActiveSection('architecture')}
              className={`text-sm font-semibold pb-1 border-b-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activeSection === 'architecture'
                  ? 'border-[#D4AF37] text-[#F0D27A]'
                  : 'border-transparent text-[#A7B8B0] hover:text-[#F7F3E8]'
              }`}
            >
              المعمارية
            </button>
          </nav>

          {/* Zone 3: 1 Primary CTA */}
          <div className="shrink-0 hidden sm:block">
            <button
              type="button"
              onClick={handleExportZip}
              disabled={exporting}
              className="inline-flex items-center gap-2 px-4 py-2 text-xs font-bold rounded-lg bg-[#D4AF37] text-[#070C0A] hover:bg-[#E6C453] transition-colors whitespace-nowrap shrink-0 cursor-pointer disabled:opacity-60"
            >
              <Download className="w-3.5 h-3.5" />
              <span>{exporting ? 'جارٍ التجهيز…' : 'تصدير أندرويد ZIP'}</span>
            </button>
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-7xl w-full mx-auto px-6 py-8">
        {activeSection === 'play' && <PlayableTable />}
        {activeSection === 'bluetooth' && <DualBluetoothSim />}
        {activeSection === 'code' && <AndroidCodeExplorer />}
        {activeSection === 'architecture' && <ArchitectureGuide />}
      </main>

      <footer className="border-t border-[#D4AF37]/15 py-5 px-6">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4 text-xs text-[#A7B8B0]">
          <span>DOMINO RIAK OFFLINE · دومينو رياك أوفلاين</span>
          <span>المالك والمطور: RIAK · مشروع أندرويد أصلي (Kotlin + Bluetooth RFCOMM)</span>
        </div>
      </footer>
    </div>
  );
}
