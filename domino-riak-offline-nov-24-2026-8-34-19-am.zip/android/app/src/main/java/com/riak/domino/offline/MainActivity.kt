package com.riak.domino.offline

import android.bluetooth.BluetoothAdapter
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.viewmodel.compose.viewModel
import com.riak.domino.offline.ui.AppScreen
import com.riak.domino.offline.ui.DominoViewModel
import com.riak.domino.offline.ui.screens.BluetoothLobbyScreen
import com.riak.domino.offline.ui.screens.GameTableScreen
import com.riak.domino.offline.ui.screens.HomeScreen
import com.riak.domino.offline.ui.theme.DominoRiakTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            DominoRiakTheme {
                val vm: DominoViewModel = viewModel()
                val uiState by vm.uiState.collectAsState()
                val btState by vm.bluetoothState.collectAsState()

                val permissionLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.RequestMultiplePermissions()
                ) {
                    vm.bluetoothController.refreshState()
                }

                val enableBtLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.StartActivityForResult()
                ) {
                    vm.bluetoothController.refreshState()
                }

                val discoverableLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.StartActivityForResult()
                ) {
                    vm.startHostingTable()
                }

                when (uiState.currentScreen) {
                    AppScreen.HOME -> HomeScreen(
                        playerName = uiState.localPlayerName,
                        showRulesDialog = uiState.showRulesDialog,
                        onPlayerNameChange = vm::updatePlayerName,
                        onHostBluetoothClick = {
                            vm.openBluetoothLobby(com.riak.domino.offline.bluetooth.BluetoothRole.HOST)
                        },
                        onJoinBluetoothClick = {
                            vm.openBluetoothLobby(com.riak.domino.offline.bluetooth.BluetoothRole.GUEST)
                        },
                        onPlayBotClick = vm::startSoloBotMatch,
                        onToggleRules = vm::setShowRulesDialog
                    )

                    AppScreen.BLUETOOTH_LOBBY -> BluetoothLobbyScreen(
                        role = uiState.lobbyMode,
                        bluetoothState = btState,
                        onRequestPermissions = {
                            permissionLauncher.launch(vm.bluetoothController.requiredPermissions())
                        },
                        onRequestEnableBluetooth = {
                            enableBtLauncher.launch(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE))
                        },
                        onMakeDiscoverable = {
                            val intent = Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE).apply {
                                putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 180)
                            }
                            discoverableLauncher.launch(intent)
                        },
                        onStartHosting = vm::startHostingTable,
                        onStartScan = { vm.bluetoothController.startDiscovery() },
                        onConnectDevice = { device -> vm.connectToHostDevice(device.address) },
                        onBack = vm::leaveToHome
                    )

                    AppScreen.GAME_TABLE -> {
                        val opponentLabel = if (uiState.gameState.isVsBot) {
                            "الذكاء المحلي"
                        } else {
                            btState.connectedPeerName ?: "منافس البلوتوث"
                        }
                        GameTableScreen(
                            state = uiState.gameState,
                            localSeat = vm.localSeat(),
                            selectedTile = uiState.selectedTile,
                            opponentName = opponentLabel,
                            onSelectTile = vm::selectTile,
                            onPlayTileOnEnd = vm::playTile,
                            onDrawTile = vm::drawFromBoneyard,
                            onPassTurn = vm::passTurn,
                            onNextRound = vm::requestNextRound,
                            onNewMatch = vm::requestNewMatch,
                            onLeaveTable = vm::leaveToHome
                        )
                    }
                }
            }
        }
    }
}
