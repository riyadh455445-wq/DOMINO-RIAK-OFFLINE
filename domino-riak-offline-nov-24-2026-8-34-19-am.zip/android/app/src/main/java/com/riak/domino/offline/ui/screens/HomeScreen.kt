package com.riak.domino.offline.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bluetooth
import androidx.compose.material.icons.rounded.BluetoothSearching
import androidx.compose.material.icons.rounded.MenuBook
import androidx.compose.material.icons.rounded.SmartToy
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.riak.domino.offline.engine.DominoTile
import com.riak.domino.offline.ui.components.DominoTileView
import com.riak.domino.offline.ui.theme.RiakColors

@Composable
fun HomeScreen(
    playerName: String,
    showRulesDialog: Boolean,
    onPlayerNameChange: (String) -> Unit,
    onHostBluetoothClick: () -> Unit,
    onJoinBluetoothClick: () -> Unit,
    onPlayBotClick: () -> Unit,
    onToggleRules: (Boolean) -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        RiakColors.ObsidianBlack,
                        RiakColors.EmeraldDeep,
                        RiakColors.ObsidianBlack
                    )
                )
            )
            .statusBarsPadding()
            .padding(horizontal = 24.dp, vertical = 20.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(top = 12.dp)
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    DominoTileView(
                        tile = DominoTile(6, 6),
                        isHorizontal = false,
                        tileLength = 68.dp,
                        tileThickness = 36.dp
                    )
                    DominoTileView(
                        tile = DominoTile(5, 3),
                        isHorizontal = false,
                        tileLength = 68.dp,
                        tileThickness = 36.dp
                    )
                }
                Spacer(modifier = Modifier.height(18.dp))
                Text(
                    text = "دومينو رياك أوفلاين",
                    style = MaterialTheme.typography.headlineLarge,
                    color = RiakColors.GoldBright,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "DOMINO RIAK OFFLINE · تطوير RIAK",
                    style = MaterialTheme.typography.bodyMedium,
                    color = RiakColors.TextMuted,
                    textAlign = TextAlign.Center
                )
            }

            Surface(
                shape = RoundedCornerShape(16.dp),
                color = RiakColors.EmeraldSurface.copy(alpha = 0.85f),
                border = BorderStroke(1.dp, RiakColors.GoldMuted.copy(alpha = 0.45f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    OutlinedTextField(
                        value = playerName,
                        onValueChange = onPlayerNameChange,
                        label = { Text("اسم اللاعب على الطاولة") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = RiakColors.ChampagneGold,
                            unfocusedBorderColor = RiakColors.GoldMuted,
                            focusedLabelColor = RiakColors.GoldBright,
                            unfocusedLabelColor = RiakColors.TextMuted,
                            focusedTextColor = RiakColors.TextIvory,
                            unfocusedTextColor = RiakColors.TextIvory
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Button(
                        onClick = onHostBluetoothClick,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = RiakColors.ChampagneGold,
                            contentColor = RiakColors.ObsidianBlack
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Bluetooth,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.size(10.dp))
                        Text(
                            text = "إنشاء طاولة بلوتوث (المضيف)",
                            fontWeight = FontWeight.Bold
                        )
                    }

                    OutlinedButton(
                        onClick = onJoinBluetoothClick,
                        border = BorderStroke(1.2.dp, RiakColors.ChampagneGold),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = RiakColors.GoldBright
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.BluetoothSearching,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.size(10.dp))
                        Text(
                            text = "الانضمام لطاولة عبر البلوتوث",
                            fontWeight = FontWeight.Bold
                        )
                    }

                    OutlinedButton(
                        onClick = onPlayBotClick,
                        border = BorderStroke(1.dp, RiakColors.GoldMuted.copy(alpha = 0.6f)),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = RiakColors.TextIvory
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.SmartToy,
                            contentDescription = null,
                            modifier = Modifier.size(19.dp)
                        )
                        Spacer(modifier = Modifier.size(10.dp))
                        Text("لعب فردي ضد الذكاء المحلي")
                    }
                }
            }

            TextButton(onClick = { onToggleRules(true) }) {
                Icon(
                    imageVector = Icons.Rounded.MenuBook,
                    contentDescription = null,
                    tint = RiakColors.ChampagneGold,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.size(8.dp))
                Text(
                    text = "قواعد اللعب والاتصال المباشر",
                    color = RiakColors.GoldBright
                )
            }
        }
    }

    if (showRulesDialog) {
        AlertDialog(
            onDismissRequest = { onToggleRules(false) },
            containerColor = RiakColors.EmeraldSurface,
            titleContentColor = RiakColors.GoldBright,
            textContentColor = RiakColors.TextIvory,
            title = { Text("قواعد دومينو رياك أوفلاين") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("• تتكون المجموعة من 28 حجراً (0 إلى 6)، يحصل كل لاعب على 7 أحجار ويبقى 14 في البنك.")
                    Text("• يبدأ الجولة الأولى صاحب أعلى دبل (أو أعلى مجموع نقاط)، ثم يبدأ الفائز الجولات التالية.")
                    Text("• عند عدم توفر حجر مطابق، يسحب اللاعب من البنك حتى يجد حجراً صالحاً أو ينفد البنك فيمرر دوره.")
                    Text("• تنتهي الجولة بنفاد أحجار أحد اللاعبين أو إغلاق الطاولة، ويُحتسب مجموع نقاط الخاسر للفائز حتى 101 نقطة.")
                    Text("• الاتصال عبر البلوتوث يعمل محلياً بالكامل بين جهازَي أندرويد دون الحاجة إلى إنترنت.")
                }
            },
            confirmButton = {
                TextButton(onClick = { onToggleRules(false) }) {
                    Text("فهمت", color = RiakColors.ChampagneGold)
                }
            }
        )
    }
}
