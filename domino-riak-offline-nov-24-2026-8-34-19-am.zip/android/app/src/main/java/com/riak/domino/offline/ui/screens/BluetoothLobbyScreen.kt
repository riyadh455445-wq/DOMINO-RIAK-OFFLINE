package com.riak.domino.offline.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Bluetooth
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.riak.domino.offline.bluetooth.BluetoothPeerDevice
import com.riak.domino.offline.bluetooth.BluetoothRole
import com.riak.domino.offline.bluetooth.BluetoothUiState
import com.riak.domino.offline.bluetooth.ConnectionPhase
import com.riak.domino.offline.ui.theme.RiakColors

@Composable
fun BluetoothLobbyScreen(
    role: BluetoothRole,
    bluetoothState: BluetoothUiState,
    onRequestPermissions: () -> Unit,
    onRequestEnableBluetooth: () -> Unit,
    onMakeDiscoverable: () -> Unit,
    onStartHosting: () -> Unit,
    onStartScan: () -> Unit,
    onConnectDevice: (BluetoothPeerDevice) -> Unit,
    onBack: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(RiakColors.ObsidianBlack)
            .statusBarsPadding()
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                    contentDescription = "رجوع",
                    tint = RiakColors.GoldBright
                )
            }
            Text(
                text = if (role == BluetoothRole.HOST) "استضافة طاولة بلوتوث" else "الانضمام لطاولة بلوتوث",
                style = MaterialTheme.typography.titleLarge,
                color = RiakColors.GoldBright
            )
            Spacer(modifier = Modifier.size(48.dp))
        }

        if (!bluetoothState.isBluetoothSupported) {
            StatusBanner(
                title = "البلوتوث غير مدعوم",
                message = "هذا الجهاز لا يحتوي على محول بلوتوث فعلي.",
                actionLabel = null,
                onAction = {}
            )
            return
        }

        if (!bluetoothState.hasPermissions) {
            StatusBanner(
                title = "صلاحيات البلوتوث مطلوبة",
                message = "نحتاج إذن البلوتوث للبحث عن الأجهزة والاتصال المباشر بدون إنترنت.",
                actionLabel = "منح الصلاحيات",
                onAction = onRequestPermissions
            )
            return
        }

        if (!bluetoothState.isBluetoothEnabled) {
            StatusBanner(
                title = "البلوتوث متوقف",
                message = "قم بتفعيل البلوتوث على جهازك للبدء في اللعب المباشر.",
                actionLabel = "تفعيل البلوتوث",
                onAction = onRequestEnableBluetooth
            )
            return
        }

        Surface(
            shape = RoundedCornerShape(14.dp),
            color = RiakColors.EmeraldSurface,
            border = BorderStroke(1.dp, RiakColors.GoldMuted.copy(alpha = 0.45f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    if (bluetoothState.phase == ConnectionPhase.HOST_LISTENING ||
                        bluetoothState.phase == ConnectionPhase.CONNECTING ||
                        bluetoothState.isScanning
                    ) {
                        CircularProgressIndicator(
                            color = RiakColors.ChampagneGold,
                            strokeWidth = 2.5.dp,
                            modifier = Modifier.size(20.dp)
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Rounded.Bluetooth,
                            contentDescription = null,
                            tint = RiakColors.ChampagneGold
                        )
                    }
                    Text(
                        text = bluetoothState.statusMessageArabic,
                        style = MaterialTheme.typography.titleMedium,
                        color = RiakColors.TextIvory
                    )
                }

                if (role == BluetoothRole.HOST) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = onMakeDiscoverable,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = RiakColors.ChampagneGold,
                                contentColor = RiakColors.ObsidianBlack
                            ),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Visibility,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.size(6.dp))
                            Text("جعل الجهاز مرئياً")
                        }
                        OutlinedButton(
                            onClick = onStartHosting,
                            border = BorderStroke(1.dp, RiakColors.GoldMuted),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = RiakColors.GoldBright),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("إعادة فتح الطاولة")
                        }
                    }
                } else {
                    Button(
                        onClick = onStartScan,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = RiakColors.ChampagneGold,
                            contentColor = RiakColors.ObsidianBlack
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Refresh,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.size(8.dp))
                        Text(if (bluetoothState.isScanning) "جارٍ المسح…" else "بحث عن أجهزة قريبة")
                    }
                }
            }
        }

        if (role == BluetoothRole.GUEST) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (bluetoothState.pairedDevices.isNotEmpty()) {
                    item {
                        Text(
                            text = "الأجهزة المقترنة مسبقاً",
                            style = MaterialTheme.typography.titleMedium,
                            color = RiakColors.GoldBright
                        )
                    }
                    items(bluetoothState.pairedDevices, key = { "paired-${it.address}" }) { device ->
                        DeviceRowCard(device = device, onClick = { onConnectDevice(device) })
                    }
                }

                if (bluetoothState.discoveredDevices.isNotEmpty()) {
                    item {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "أجهزة مكتشفة قريبة",
                            style = MaterialTheme.typography.titleMedium,
                            color = RiakColors.GoldBright
                        )
                    }
                    items(bluetoothState.discoveredDevices, key = { "disc-${it.address}" }) { device ->
                        DeviceRowCard(device = device, onClick = { onConnectDevice(device) })
                    }
                }
            }
        }
    }
}

@Composable
private fun DeviceRowCard(
    device: BluetoothPeerDevice,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = RiakColors.EmeraldDeep,
        border = BorderStroke(1.dp, RiakColors.GoldMuted.copy(alpha = 0.35f)),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    text = device.name,
                    style = MaterialTheme.typography.titleMedium,
                    color = RiakColors.TextIvory,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = device.address,
                    style = MaterialTheme.typography.bodyMedium,
                    color = RiakColors.TextMuted
                )
            }
            Text(
                text = "اتصال",
                style = MaterialTheme.typography.labelLarge,
                color = RiakColors.ChampagneGold
            )
        }
    }
}

@Composable
private fun StatusBanner(
    title: String,
    message: String,
    actionLabel: String?,
    onAction: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = RiakColors.EmeraldSurface,
        border = BorderStroke(1.dp, RiakColors.ChampagneGold.copy(alpha = 0.5f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(text = title, style = MaterialTheme.typography.titleLarge, color = RiakColors.GoldBright)
            Text(text = message, style = MaterialTheme.typography.bodyMedium, color = RiakColors.TextIvory)
            if (actionLabel != null) {
                Button(
                    onClick = onAction,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = RiakColors.ChampagneGold,
                        contentColor = RiakColors.ObsidianBlack
                    )
                ) {
                    Text(actionLabel)
                }
            }
        }
    }
}
