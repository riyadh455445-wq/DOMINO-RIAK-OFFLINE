package com.riak.domino.offline.bluetooth

import com.riak.domino.offline.engine.BoardEnd
import com.riak.domino.offline.engine.DominoGameState
import com.riak.domino.offline.engine.DominoTile
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

@Serializable
sealed interface BluetoothPacket {

    @Serializable
    @SerialName("handshake")
    data class Handshake(
        val playerName: String,
        val appVersion: String = "1.0.0"
    ) : BluetoothPacket

    @Serializable
    @SerialName("state_sync")
    data class StateSync(
        val state: DominoGameState
    ) : BluetoothPacket

    @Serializable
    @SerialName("play_tile")
    data class PlayTile(
        val tile: DominoTile,
        val end: BoardEnd
    ) : BluetoothPacket

    @Serializable
    @SerialName("draw_tile")
    data object DrawTile : BluetoothPacket

    @Serializable
    @SerialName("pass_turn")
    data object PassTurn : BluetoothPacket

    @Serializable
    @SerialName("request_next_round")
    data object RequestNextRound : BluetoothPacket

    @Serializable
    @SerialName("request_new_match")
    data object RequestNewMatch : BluetoothPacket

    @Serializable
    @SerialName("ping")
    data class Ping(val timestampMs: Long) : BluetoothPacket

    companion object {
        val json = Json {
            ignoreUnknownKeys = true
            classDiscriminator = "type"
        }

        fun encodeLine(packet: BluetoothPacket): String = json.encodeToString(packet) + "\n"

        fun decodeLine(line: String): BluetoothPacket? = runCatching {
            json.decodeFromString<BluetoothPacket>(line.trim())
        }.getOrNull()
    }
}
