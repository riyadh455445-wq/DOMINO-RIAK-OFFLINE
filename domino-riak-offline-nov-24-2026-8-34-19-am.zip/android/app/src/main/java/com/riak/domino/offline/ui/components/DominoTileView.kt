package com.riak.domino.offline.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.riak.domino.offline.engine.DominoTile
import com.riak.domino.offline.ui.theme.RiakColors

@Composable
fun DominoTileView(
    tile: DominoTile,
    modifier: Modifier = Modifier,
    isHorizontal: Boolean = false,
    isPlayable: Boolean = true,
    isSelected: Boolean = false,
    tileLength: Dp = 76.dp,
    tileThickness: Dp = 40.dp,
    onClick: (() -> Unit)? = null
) {
    val width = if (isHorizontal) tileLength else tileThickness
    val height = if (isHorizontal) tileThickness else tileLength
    val borderColor = when {
        isSelected -> RiakColors.GoldBright
        isPlayable -> RiakColors.ChampagneGold.copy(alpha = 0.75f)
        else -> RiakColors.IvoryEdge
    }
    val borderWidth = if (isSelected) 2.5.dp else 1.2.dp

    Box(
        modifier = modifier
            .size(width = width, height = height)
            .alpha(if (isPlayable) 1f else 0.45f)
            .clip(RoundedCornerShape(8.dp))
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(RiakColors.IvoryTile, RiakColors.IvoryEdge)
                )
            )
            .border(width = borderWidth, color = borderColor, shape = RoundedCornerShape(8.dp))
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
    ) {
        Canvas(modifier = Modifier.matchParentSize()) {
            val w = size.width
            val h = size.height
            val dividerThickness = 2.dp.toPx()

            if (isHorizontal) {
                val halfW = w / 2f
                drawRoundRect(
                    color = RiakColors.ChampagneGold,
                    topLeft = Offset(halfW - dividerThickness / 2f, h * 0.14f),
                    size = Size(dividerThickness, h * 0.72f),
                    cornerRadius = CornerRadius(2f, 2f)
                )
                drawPips(
                    count = tile.left,
                    boxTopLeft = Offset(0f, 0f),
                    boxSize = Size(halfW, h)
                )
                drawPips(
                    count = tile.right,
                    boxTopLeft = Offset(halfW, 0f),
                    boxSize = Size(halfW, h)
                )
            } else {
                val halfH = h / 2f
                drawRoundRect(
                    color = RiakColors.ChampagneGold,
                    topLeft = Offset(w * 0.14f, halfH - dividerThickness / 2f),
                    size = Size(w * 0.72f, dividerThickness),
                    cornerRadius = CornerRadius(2f, 2f)
                )
                drawPips(
                    count = tile.left,
                    boxTopLeft = Offset(0f, 0f),
                    boxSize = Size(w, halfH)
                )
                drawPips(
                    count = tile.right,
                    boxTopLeft = Offset(0f, halfH),
                    boxSize = Size(w, halfH)
                )
            }
        }
    }
}

@Composable
fun DominoBackTile(
    modifier: Modifier = Modifier,
    width: Dp = 20.dp,
    height: Dp = 32.dp
) {
    Box(
        modifier = modifier
            .size(width = width, height = height)
            .clip(RoundedCornerShape(4.dp))
            .background(RiakColors.ObsidianBlack)
            .border(1.dp, RiakColors.ChampagneGold.copy(alpha = 0.6f), RoundedCornerShape(4.dp))
    )
}

private fun DrawScope.drawPips(
    count: Int,
    boxTopLeft: Offset,
    boxSize: Size
) {
    if (count == 0) return
    val pipRadius = minOf(boxSize.width, boxSize.height) * 0.095f
    val padX = boxSize.width * 0.26f
    val padY = boxSize.height * 0.26f

    val leftX = boxTopLeft.x + padX
    val midX = boxTopLeft.x + boxSize.width * 0.5f
    val rightX = boxTopLeft.x + boxSize.width - padX

    val topY = boxTopLeft.y + padY
    val midY = boxTopLeft.y + boxSize.height * 0.5f
    val botY = boxTopLeft.y + boxSize.height - padY

    val points: List<Offset> = when (count) {
        1 -> listOf(Offset(midX, midY))
        2 -> listOf(Offset(leftX, topY), Offset(rightX, botY))
        3 -> listOf(Offset(leftX, topY), Offset(midX, midY), Offset(rightX, botY))
        4 -> listOf(
            Offset(leftX, topY), Offset(rightX, topY),
            Offset(leftX, botY), Offset(rightX, botY)
        )
        5 -> listOf(
            Offset(leftX, topY), Offset(rightX, topY),
            Offset(midX, midY),
            Offset(leftX, botY), Offset(rightX, botY)
        )
        6 -> listOf(
            Offset(leftX, topY), Offset(rightX, topY),
            Offset(leftX, midY), Offset(rightX, midY),
            Offset(leftX, botY), Offset(rightX, botY)
        )
        else -> emptyList()
    }

    val pipColor: Color = if (count == 6 || count == 1) RiakColors.GoldMuted else RiakColors.PipObsidian
    for (pt in points) {
        drawCircle(
            color = pipColor,
            radius = pipRadius,
            center = pt
        )
    }
}
