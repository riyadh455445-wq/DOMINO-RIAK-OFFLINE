package com.riak.domino.offline.engine

import kotlinx.serialization.Serializable

@Serializable
data class DominoTile(
    val left: Int,
    val right: Int
) {
    init {
        require(left in 0..6 && right in 0..6) {
            "Domino pips must be in range 0..6, got [$left|$right]"
        }
    }

    val id: String get() = "${minOf(left, right)}-${maxOf(left, right)}"
    val isDouble: Boolean get() = left == right
    val pipSum: Int get() = left + right

    fun flipped(): DominoTile = DominoTile(left = right, right = left)

    fun matches(pip: Int): Boolean = left == pip || right == pip

    companion object {
        fun fullDoubleSixSet(): List<DominoTile> = buildList(28) {
            for (i in 0..6) {
                for (j in i..6) {
                    add(DominoTile(i, j))
                }
            }
        }
    }
}

@Serializable
enum class BoardEnd {
    LEFT,
    RIGHT
}

@Serializable
enum class PlayerSeat {
    HOST,
    GUEST,
    BOT
}

@Serializable
enum class GamePhase {
    IDLE,
    PLAYING,
    ROUND_OVER,
    MATCH_OVER
}

@Serializable
enum class RoundEndReason {
    DOMINO_OUT,
    BLOCKED_BOARD
}

@Serializable
data class PlacedTile(
    val tile: DominoTile,
    val playedBy: PlayerSeat
)

@Serializable
data class LegalMove(
    val tile: DominoTile,
    val end: BoardEnd
)

@Serializable
data class RoundSummary(
    val roundNumber: Int,
    val winner: PlayerSeat?,
    val reason: RoundEndReason,
    val pointsAwarded: Int,
    val hostRemainingPips: Int,
    val guestRemainingPips: Int
)

@Serializable
data class DominoGameState(
    val roundNumber: Int = 1,
    val targetScore: Int = 101,
    val phase: GamePhase = GamePhase.IDLE,
    val board: List<PlacedTile> = emptyList(),
    val leftEnd: Int? = null,
    val rightEnd: Int? = null,
    val hostHand: List<DominoTile> = emptyList(),
    val guestHand: List<DominoTile> = emptyList(),
    val boneyard: List<DominoTile> = emptyList(),
    val currentTurn: PlayerSeat = PlayerSeat.HOST,
    val hostScore: Int = 0,
    val guestScore: Int = 0,
    val consecutivePasses: Int = 0,
    val lastRoundSummary: RoundSummary? = null,
    val lastActionArabic: String = "جاهز لبدء الجولة",
    val isVsBot: Boolean = false
) {
    val opponentSeat: PlayerSeat get() = if (isVsBot) PlayerSeat.BOT else PlayerSeat.GUEST

    fun handFor(seat: PlayerSeat): List<DominoTile> = when (seat) {
        PlayerSeat.HOST -> hostHand
        PlayerSeat.GUEST, PlayerSeat.BOT -> guestHand
    }
}
