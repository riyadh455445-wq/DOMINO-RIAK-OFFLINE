package com.riak.domino.offline.bluetooth

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.IOException
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.util.UUID

data class BluetoothPeerDevice(
    val name: String,
    val address: String,
    val isPaired: Boolean
)

enum class BluetoothRole {
    NONE,
    HOST,
    GUEST
}

enum class ConnectionPhase {
    DISCONNECTED,
    HOST_LISTENING,
    CONNECTING,
    CONNECTED,
    ERROR
}

data class BluetoothUiState(
    val isBluetoothSupported: Boolean = true,
    val isBluetoothEnabled: Boolean = false,
    val hasPermissions: Boolean = false,
    val isScanning: Boolean = false,
    val role: BluetoothRole = BluetoothRole.NONE,
    val phase: ConnectionPhase = ConnectionPhase.DISCONNECTED,
    val pairedDevices: List<BluetoothPeerDevice> = emptyList(),
    val discoveredDevices: List<BluetoothPeerDevice> = emptyList(),
    val connectedPeerName: String? = null,
    val statusMessageArabic: String = "جاهز للاتصال عبر البلوتوث"
)

class BluetoothController(private val context: Context) {

    companion object {
        const val SERVICE_NAME = "DominoRiakOfflineService"
        val SERVICE_UUID: UUID = UUID.fromString("8a4d2c9e-6f1b-4c3a-9e2d-7b5a1d4f8c01")
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val bluetoothManager: BluetoothManager? =
        context.getSystemService(BluetoothManager::class.java)
    private val adapter: BluetoothAdapter? = bluetoothManager?.adapter

    private val _uiState = MutableStateFlow(
        BluetoothUiState(
            isBluetoothSupported = adapter != null,
            isBluetoothEnabled = adapter?.isEnabled == true,
            hasPermissions = hasRequiredPermissions()
        )
    )
    val uiState: StateFlow<BluetoothUiState> = _uiState.asStateFlow()

    private val _incomingPackets = MutableSharedFlow<BluetoothPacket>(extraBufferCapacity = 32)
    val incomingPackets: SharedFlow<BluetoothPacket> = _incomingPackets.asSharedFlow()

    private var serverSocket: BluetoothServerSocket? = null
    private var activeSocket: BluetoothSocket? = null
    private var writer: BufferedWriter? = null
    private var connectionJob: Job? = null
    private var isReceiverRegistered = false

    private val discoveryReceiver = object : BroadcastReceiver() {
        @SuppressLint("MissingPermission")
        override fun onReceive(ctx: Context?, intent: Intent?) {
            when (intent?.action) {
                BluetoothDevice.ACTION_FOUND -> {
                    val device: BluetoothDevice? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                    } else {
                        @Suppress("DEPRECATION")
                        intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                    }
                    device?.let { found ->
                        if (!hasRequiredPermissions()) return
                        val peer = BluetoothPeerDevice(
                            name = found.name ?: "جهاز أندرويد غير مسمى",
                            address = found.address,
                            isPaired = found.bondState == BluetoothDevice.BOND_BONDED
                        )
                        _uiState.update { state ->
                            if (state.discoveredDevices.any { it.address == peer.address }) {
                                state
                            } else {
                                state.copy(discoveredDevices = state.discoveredDevices + peer)
                            }
                        }
                    }
                }

                BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> {
                    _uiState.update { it.copy(isScanning = false) }
                }

                BluetoothAdapter.ACTION_STATE_CHANGED -> {
                    _uiState.update {
                        it.copy(isBluetoothEnabled = adapter?.isEnabled == true)
                    }
                }
            }
        }
    }

    fun requiredPermissions(): Array<String> = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        arrayOf(
            Manifest.permission.BLUETOOTH_SCAN,
            Manifest.permission.BLUETOOTH_CONNECT,
            Manifest.permission.BLUETOOTH_ADVERTISE
        )
    } else {
        arrayOf(
            Manifest.permission.BLUETOOTH,
            Manifest.permission.BLUETOOTH_ADMIN,
            Manifest.permission.ACCESS_FINE_LOCATION
        )
    }

    fun hasRequiredPermissions(): Boolean {
        return requiredPermissions().all { perm ->
            ContextCompat.checkSelfPermission(context, perm) == PackageManager.PERMISSION_GRANTED
        }
    }

    fun refreshState() {
        val perms = hasRequiredPermissions()
        val enabled = adapter?.isEnabled == true
        _uiState.update {
            it.copy(
                isBluetoothSupported = adapter != null,
                isBluetoothEnabled = enabled,
                hasPermissions = perms
            )
        }
        if (perms && enabled) {
            refreshPairedDevices()
        }
    }

    @SuppressLint("MissingPermission")
    fun refreshPairedDevices() {
        if (!hasRequiredPermissions() || adapter == null) return
        val paired = adapter.bondedDevices
            ?.map {
                BluetoothPeerDevice(
                    name = it.name ?: "جهاز مقترن",
                    address = it.address,
                    isPaired = true
                )
            }
            ?.sortedBy { it.name }
            ?: emptyList()
        _uiState.update { it.copy(pairedDevices = paired) }
    }

    @SuppressLint("MissingPermission")
    fun startDiscovery() {
        if (!hasRequiredPermissions() || adapter == null || !adapter.isEnabled) return
        ensureReceiverRegistered()
        refreshPairedDevices()
        if (adapter.isDiscovering) {
            adapter.cancelDiscovery()
        }
        _uiState.update {
            it.copy(
                isScanning = true,
                discoveredDevices = emptyList(),
                statusMessageArabic = "جارٍ البحث عن أجهزة دومينو قريبة…"
            )
        }
        adapter.startDiscovery()
    }

    @SuppressLint("MissingPermission")
    fun stopDiscovery() {
        if (!hasRequiredPermissions() || adapter == null) return
        if (adapter.isDiscovering) {
            adapter.cancelDiscovery()
        }
        _uiState.update { it.copy(isScanning = false) }
    }

    @SuppressLint("MissingPermission")
    fun startHosting(localPlayerName: String) {
        if (!hasRequiredPermissions() || adapter == null || !adapter.isEnabled) {
            _uiState.update {
                it.copy(
                    phase = ConnectionPhase.ERROR,
                    statusMessageArabic = "يرجى تفعيل البلوتوث ومنح الصلاحيات أولاً"
                )
            }
            return
        }

        closeConnectionsInternal()
        stopDiscovery()

        _uiState.update {
            it.copy(
                role = BluetoothRole.HOST,
                phase = ConnectionPhase.HOST_LISTENING,
                statusMessageArabic = "الطاولة مفتوحة · بانتظار انضمام منافس عبر البلوتوث"
            )
        }

        connectionJob = scope.launch {
            try {
                val srv = adapter.listenUsingRfcommWithServiceRecord(SERVICE_NAME, SERVICE_UUID)
                serverSocket = srv
                val socket = srv.accept()
                srv.close()
                serverSocket = null
                onSocketEstablished(socket, BluetoothRole.HOST, localPlayerName)
            } catch (e: IOException) {
                if (isActive) {
                    _uiState.update {
                        it.copy(
                            phase = ConnectionPhase.ERROR,
                            statusMessageArabic = "تعذر استقبال اتصال البلوتوث: ${e.localizedMessage ?: "خطأ"}"
                        )
                    }
                }
            }
        }
    }

    @SuppressLint("MissingPermission")
    fun connectToHost(address: String, localPlayerName: String) {
        if (!hasRequiredPermissions() || adapter == null || !adapter.isEnabled) {
            _uiState.update {
                it.copy(
                    phase = ConnectionPhase.ERROR,
                    statusMessageArabic = "يرجى تفعيل البلوتوث ومنح الصلاحيات أولاً"
                )
            }
            return
        }

        closeConnectionsInternal()
        stopDiscovery()

        _uiState.update {
            it.copy(
                role = BluetoothRole.GUEST,
                phase = ConnectionPhase.CONNECTING,
                statusMessageArabic = "جارٍ الاتصال بطاولة المضيف…"
            )
        }

        connectionJob = scope.launch {
            try {
                val device = adapter.getRemoteDevice(address)
                val socket = device.createRfcommSocketToServiceRecord(SERVICE_UUID)
                socket.connect()
                onSocketEstablished(socket, BluetoothRole.GUEST, localPlayerName)
            } catch (e: IOException) {
                _uiState.update {
                    it.copy(
                        phase = ConnectionPhase.ERROR,
                        statusMessageArabic = "فشل الاتصال بالجهاز: تأكد أن المضيف فتح الطاولة"
                    )
                }
            }
        }
    }

    @SuppressLint("MissingPermission")
    private suspend fun onSocketEstablished(
        socket: BluetoothSocket,
        role: BluetoothRole,
        localPlayerName: String
    ) {
        activeSocket = socket
        writer = BufferedWriter(OutputStreamWriter(socket.outputStream, Charsets.UTF_8))
        val peerName = runCatching { socket.remoteDevice?.name }.getOrNull() ?: "منافس بلوتوث"

        _uiState.update {
            it.copy(
                role = role,
                phase = ConnectionPhase.CONNECTED,
                connectedPeerName = peerName,
                statusMessageArabic = "متصل الآن مع $peerName"
            )
        }

        sendPacket(BluetoothPacket.Handshake(playerName = localPlayerName))

        val reader = BufferedReader(InputStreamReader(socket.inputStream, Charsets.UTF_8))
        try {
            while (scope.isActive) {
                val line = reader.readLine() ?: break
                val packet = BluetoothPacket.decodeLine(line) ?: continue
                if (packet is BluetoothPacket.Handshake) {
                    _uiState.update {
                        it.copy(
                            connectedPeerName = packet.playerName,
                            statusMessageArabic = "متصل مع ${packet.playerName}"
                        )
                    }
                }
                _incomingPackets.emit(packet)
            }
        } catch (_: IOException) {
            // Stream closed on disconnect
        } finally {
            _uiState.update {
                it.copy(
                    phase = ConnectionPhase.DISCONNECTED,
                    connectedPeerName = null,
                    statusMessageArabic = "انقطع اتصال البلوتوث"
                )
            }
            closeConnectionsInternal()
        }
    }

    fun sendPacket(packet: BluetoothPacket) {
        scope.launch {
            try {
                val out = writer ?: return@launch
                out.write(BluetoothPacket.encodeLine(packet))
                out.flush()
            } catch (_: IOException) {
                _uiState.update {
                    it.copy(
                        phase = ConnectionPhase.ERROR,
                        statusMessageArabic = "تعذر إرسال البيانات عبر البلوتوث"
                    )
                }
            }
        }
    }

    fun disconnect() {
        closeConnectionsInternal()
        _uiState.update {
            it.copy(
                role = BluetoothRole.NONE,
                phase = ConnectionPhase.DISCONNECTED,
                connectedPeerName = null,
                statusMessageArabic = "تم قطع الاتصال"
            )
        }
    }

    private fun closeConnectionsInternal() {
        connectionJob?.cancel()
        connectionJob = null
        runCatching { writer?.close() }
        writer = null
        runCatching { activeSocket?.close() }
        activeSocket = null
        runCatching { serverSocket?.close() }
        serverSocket = null
    }

    private fun ensureReceiverRegistered() {
        if (isReceiverRegistered) return
        val filter = IntentFilter().apply {
            addAction(BluetoothDevice.ACTION_FOUND)
            addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
            addAction(BluetoothAdapter.ACTION_STATE_CHANGED)
        }
        ContextCompat.registerReceiver(
            context,
            discoveryReceiver,
            filter,
            ContextCompat.RECEIVER_EXPORTED
        )
        isReceiverRegistered = true
    }

    fun release() {
        stopDiscovery()
        closeConnectionsInternal()
        if (isReceiverRegistered) {
            runCatching { context.unregisterReceiver(discoveryReceiver) }
            isReceiverRegistered = false
        }
    }
}
