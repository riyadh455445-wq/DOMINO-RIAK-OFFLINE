package com.riak.domino.offline.engine

sealed interface BotDecision {
    data class Play(val move: LegalMove) : BotDecision
    data object Draw : BotDecision
    data object Pass : BotDecision
}

object DominoBot {

    /**
     * Heuristic offline bot:
     * 1. Prefers doubles when legal to shed symmetrical constraints early.
     * 2. Sheds higher pip-count tiles first to minimize locked-board penalty.
     * 3. Favors leaving board ends matching suits still held in hand.
     */
    fun chooseAction(state: DominoGameState, botSeat: PlayerSeat = PlayerSeat.BOT): BotDecision {
        val legalMoves = DominoEngine.legalMovesForSeat(state, botSeat)
        if (legalMoves.isNotEmpty()) {
            val hand = state.handFor(botSeat)
            val best = legalMoves.maxByOrNull { move ->
                val remaining = hand.filterNot { it.id == move.tile.id }
                val newOpenEnd = when {
                    state.board.isEmpty() -> move.tile.right
                    move.end == BoardEnd.LEFT -> if (move.tile.right == state.leftEnd) move.tile.left else move.tile.right
                    else -> if (move.tile.left == state.rightEnd) move.tile.right else move.tile.left
                }
                val followUpSupport = remaining.count { it.matches(newOpenEnd) }
                val doubleBonus = if (move.tile.isDouble) 8 else 0
                move.tile.pipSum * 2 + doubleBonus + followUpSupport * 3
            }!!
            return BotDecision.Play(best)
        }

        return if (state.boneyard.isNotEmpty()) {
            BotDecision.Draw
        } else {
            BotDecision.Pass
        }
    }
}
