package com.riak.domino.offline.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ExitToApp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.riak.domino.offline.engine.BoardEnd
import com.riak.domino.offline.engine.DominoEngine
import com.riak.domino.offline.engine.DominoGameState
import com.riak.domino.offline.engine.DominoTile
import com.riak.domino.offline.engine.GamePhase
import com.riak.domino.offline.engine.PlayerSeat
import com.riak.domino.offline.ui.components.DominoBackTile
import com.riak.domino.offline.ui.components.DominoTileView
import com.riak.domino.offline.ui.theme.RiakColors

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun GameTableScreen(
    state: DominoGameState,
    localSeat: PlayerSeat,
    selectedTile: DominoTile?,
    opponentName: String,
    onSelectTile: (DominoTile) -> Unit,
    onPlayTileOnEnd: (DominoTile, BoardEnd) -> Unit,
    onDrawTile: () -> Unit,
    onPassTurn: () -> Unit,
    onNextRound: () -> Unit,
    onNewMatch: () -> Unit,
    onLeaveTable: () -> Unit
) {
    val myHand = state.handFor(localSeat)
    val opponentHandCount = if (localSeat == PlayerSeat.HOST) state.guestHand.size else state.hostHand.size
    val myScore = if (localSeat == PlayerSeat.HOST) state.hostScore else state.guestScore
    val opponentScore = if (localSeat == PlayerSeat.HOST) state.guestScore else state.hostScore
    val isMyTurn = state.phase == GamePhase.PLAYING && state.currentTurn == localSeat
    val myLegalMoves = DominoEngine.legalMovesForSeat(state, localSeat)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(RiakColors.EmeraldFelt, RiakColors.EmeraldDeep, RiakColors.ObsidianBlack)
                )
            )
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Score & Opponent HUD
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = RiakColors.ObsidianBlack.copy(alpha = 0.78f),
                border = BorderStroke(1.dp, RiakColors.GoldMuted.copy(alpha = 0.45f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "أنت: $myScore · $opponentName: $opponentScore",
                            style = MaterialTheme.typography.titleMedium,
                            color = RiakColors.GoldBright
                        )
                        Text(
                            text = "الجولة ${state.roundNumber} · الهدف ${state.targetScore}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = RiakColors.TextMuted
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = if (isMyTurn) "دورك الآن" else "دور $opponentName",
                            style = MaterialTheme.typography.labelLarge,
                            color = if (isMyTurn) RiakColors.GoldBright else RiakColors.TextMuted
                        )
                        IconButton(onClick = onLeaveTable) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.ExitToApp,
                                contentDescription = "مغادرة",
                                tint = RiakColors.TextMuted
                            )
                        }
                    }
                }
            }

            // Opponent hand backs
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                repeat(opponentHandCount.coerceAtMost(10)) {
                    DominoBackTile(modifier = Modifier.padding(horizontal = 2.dp))
                }
                if (opponentHandCount > 10) {
                    Text(
                        text = "+${opponentHandCount - 10}",
                        color = RiakColors.GoldBright,
                        modifier = Modifier.padding(start = 6.dp)
                    )
                }
            }

            // Center Domino Felt Board
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .border(
                        width = 1.5.dp,
                        color = RiakColors.GoldMuted.copy(alpha = 0.4f),
                        shape = RoundedCornerShape(18.dp)
                    )
                    .background(
                        color = RiakColors.EmeraldDeep.copy(alpha = 0.6f),
                        shape = RoundedCornerShape(18.dp)
                    )
                    .padding(14.dp),
                contentAlignment = Alignment.Center
            ) {
                if (state.board.isEmpty()) {
                    Text(
                        text = "اختر حجراً من يدك لوضعه على الطاولة",
                        style = MaterialTheme.typography.titleMedium,
                        color = RiakColors.TextMuted
                    )
                } else {
                    FlowRow(
                        modifier = Modifier
                            .fillMaxWidth()
                            .verticalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(4.dp, Alignment.CenterHorizontally),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        state.board.forEach { placed ->
                            val isDouble = placed.tile.isDouble
                            DominoTileView(
                                tile = placed.tile,
                                isHorizontal = !isDouble,
                                tileLength = 60.dp,
                                tileThickness = 32.dp
                            )
                        }
                    }
                }
            }

            // Action bar + status + ambiguity Left/Right choice
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "${state.lastActionArabic} · البنك: ${state.boneyard.size}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = RiakColors.TextMuted
                )

                if (selectedTile != null && isMyTurn && state.board.isNotEmpty()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { onPlayTileOnEnd(selectedTile, BoardEnd.LEFT) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = RiakColors.ChampagneGold,
                                contentColor = RiakColors.ObsidianBlack
                            ),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("وضع على الطرف (${state.leftEnd})")
                        }
                        Button(
                            onClick = { onPlayTileOnEnd(selectedTile, BoardEnd.RIGHT) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = RiakColors.ChampagneGold,
                                contentColor = RiakColors.ObsidianBlack
                            ),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("وضع على الطرف (${state.rightEnd})")
                        }
                    }
                } else if (isMyTurn && myLegalMoves.isEmpty()) {
                    if (state.boneyard.isNotEmpty()) {
                        Button(
                            onClick = onDrawTile,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = RiakColors.ChampagneGold,
                                contentColor = RiakColors.ObsidianBlack
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("سحب حجر من البنك (${state.boneyard.size})")
                        }
                    } else {
                        OutlinedButton(
                            onClick = onPassTurn,
                            border = BorderStroke(1.2.dp, RiakColors.ChampagneGold),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = RiakColors.GoldBright),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("تمرير الدور (لا يوجد حجر صالح)")
                        }
                    }
                }

                // Player hand tray
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    myHand.forEach { tile ->
                        val playable = isMyTurn && myLegalMoves.any { it.tile.id == tile.id }
                        DominoTileView(
                            tile = tile,
                            isHorizontal = false,
                            isPlayable = playable,
                            isSelected = selectedTile?.id == tile.id,
                            tileLength = 82.dp,
                            tileThickness = 44.dp,
                            onClick = if (playable) {
                                { onSelectTile(tile) }
                            } else {
                                null
                            }
                        )
                    }
                }
            }
        }

        // Round / Match Summary Overlay
        val summary = state.lastRoundSummary
        if ((state.phase == GamePhase.ROUND_OVER || state.phase == GamePhase.MATCH_OVER) && summary != null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(RiakColors.ObsidianBlack.copy(alpha = 0.82f))
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = RiakColors.EmeraldSurface,
                    border = BorderStroke(1.5.dp, RiakColors.ChampagneGold),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(22.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = if (state.phase == GamePhase.MATCH_OVER) "انتهت المباراة" else "نتيجة الجولة ${summary.roundNumber}",
                            style = MaterialTheme.typography.headlineLarge,
                            color = RiakColors.GoldBright,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = state.lastActionArabic,
                            style = MaterialTheme.typography.titleMedium,
                            color = RiakColors.TextIvory
                        )
                        Text(
                            text = "أنت: $myScore نقطة · $opponentName: $opponentScore نقطة",
                            style = MaterialTheme.typography.bodyMedium,
                            color = RiakColors.TextMuted
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        if (state.phase == GamePhase.ROUND_OVER) {
                            Button(
                                onClick = onNextRound,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = RiakColors.ChampagneGold,
                                    contentColor = RiakColors.ObsidianBlack
                                ),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("بدء الجولة التالية", fontWeight = FontWeight.Bold)
                            }
                        } else {
                            Button(
                                onClick = onNewMatch,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = RiakColors.ChampagneGold,
                                    contentColor = RiakColors.ObsidianBlack
                                ),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("مباراة جديدة", fontWeight = FontWeight.Bold)
                            }
                        }
                        OutlinedButton(
                            onClick = onLeaveTable,
                            border = BorderStroke(1.dp, RiakColors.GoldMuted),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = RiakColors.TextIvory),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("العودة للرئيسية")
                        }
                    }
                }
            }
        }
    }
}
