package com.riak.domino.offline.ui

import android.app.Application
import android.os.Build
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.riak.domino.offline.bluetooth.BluetoothController
import com.riak.domino.offline.bluetooth.BluetoothPacket
import com.riak.domino.offline.bluetooth.BluetoothRole
import com.riak.domino.offline.bluetooth.BluetoothUiState
import com.riak.domino.offline.bluetooth.ConnectionPhase
import com.riak.domino.offline.engine.BoardEnd
import com.riak.domino.offline.engine.BotDecision
import com.riak.domino.offline.engine.DominoBot
import com.riak.domino.offline.engine.DominoEngine
import com.riak.domino.offline.engine.DominoGameState
import com.riak.domino.offline.engine.DominoTile
import com.riak.domino.offline.engine.GamePhase
import com.riak.domino.offline.engine.PlayerSeat
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class AppScreen {
    HOME,
    BLUETOOTH_LOBBY,
    GAME_TABLE
}

data class DominoAppUiState(
    val currentScreen: AppScreen = AppScreen.HOME,
    val lobbyMode: BluetoothRole = BluetoothRole.HOST,
    val localPlayerName: String = Build.MODEL?.takeIf { it.isNotBlank() } ?: "لاعب رياك",
    val gameState: DominoGameState = DominoGameState(),
    val selectedTile: DominoTile? = null,
    val showRulesDialog: Boolean = false
)

class DominoViewModel(application: Application) : AndroidViewModel(application) {

    val bluetoothController = BluetoothController(application.applicationContext)
    val bluetoothState: StateFlow<BluetoothUiState> = bluetoothController.uiState

    private val _uiState = MutableStateFlow(DominoAppUiState())
    val uiState: StateFlow<DominoAppUiState> = _uiState.asStateFlow()

    init {
        observeBluetoothPackets()
        observeConnectionPhase()
    }

    private fun observeConnectionPhase() {
        viewModelScope.launch {
            bluetoothState.collect { bt ->
                if (bt.phase == ConnectionPhase.CONNECTED && bt.role == BluetoothRole.HOST) {
                    val current = _uiState.value.gameState
                    if (current.phase == GamePhase.IDLE || current.isVsBot) {
                        val started = DominoEngine.startNewMatch(targetScore = 101, isVsBot = false)
                        _uiState.update {
                            it.copy(
                                currentScreen = AppScreen.GAME_TABLE,
                                gameState = started,
                                selectedTile = null
                            )
                        }
                        bluetoothController.sendPacket(BluetoothPacket.StateSync(started))
                    }
                }
            }
        }
    }

    private fun observeBluetoothPackets() {
        viewModelScope.launch {
            bluetoothController.incomingPackets.collect { packet ->
                val bt = bluetoothState.value
                when (packet) {
                    is BluetoothPacket.StateSync -> {
                        if (bt.role == BluetoothRole.GUEST) {
                            _uiState.update {
                                it.copy(
                                    currentScreen = AppScreen.GAME_TABLE,
                                    gameState = packet.state,
                                    selectedTile = null
                                )
                            }
                        }
                    }

                    is BluetoothPacket.PlayTile -> {
                        if (bt.role == BluetoothRole.HOST) {
                            DominoEngine.playTile(
                                _uiState.value.gameState,
                                PlayerSeat.GUEST,
                                packet.tile,
                                packet.end
                            ).onSuccess { updated ->
                                _uiState.update { it.copy(gameState = updated, selectedTile = null) }
                                bluetoothController.sendPacket(BluetoothPacket.StateSync(updated))
                            }
                        }
                    }

                    BluetoothPacket.DrawTile -> {
                        if (bt.role == BluetoothRole.HOST) {
                            DominoEngine.drawFromBoneyard(_uiState.value.gameState, PlayerSeat.GUEST)
                                .onSuccess { updated ->
                                    _uiState.update { it.copy(gameState = updated) }
                                    bluetoothController.sendPacket(BluetoothPacket.StateSync(updated))
                                }
                        }
                    }

                    BluetoothPacket.PassTurn -> {
                        if (bt.role == BluetoothRole.HOST) {
                            DominoEngine.passTurn(_uiState.value.gameState, PlayerSeat.GUEST)
                                .onSuccess { updated ->
                                    _uiState.update { it.copy(gameState = updated) }
                                    bluetoothController.sendPacket(BluetoothPacket.StateSync(updated))
                                }
                        }
                    }

                    BluetoothPacket.RequestNextRound -> {
                        if (bt.role == BluetoothRole.HOST) {
                            startNextRoundInternal()
                        }
                    }

                    BluetoothPacket.RequestNewMatch -> {
                        if (bt.role == BluetoothRole.HOST) {
                            val fresh = DominoEngine.startNewMatch(targetScore = 101, isVsBot = false)
                            _uiState.update { it.copy(gameState = fresh, selectedTile = null) }
                            bluetoothController.sendPacket(BluetoothPacket.StateSync(fresh))
                        }
                    }

                    is BluetoothPacket.Handshake, is BluetoothPacket.Ping -> Unit
                }
            }
        }
    }

    fun localSeat(): PlayerSeat {
        return when {
            _uiState.value.gameState.isVsBot -> PlayerSeat.HOST
            bluetoothState.value.role == BluetoothRole.GUEST -> PlayerSeat.GUEST
            else -> PlayerSeat.HOST
        }
    }

    fun updatePlayerName(name: String) {
        _uiState.update { it.copy(localPlayerName = name.take(20)) }
    }

    fun openBluetoothLobby(role: BluetoothRole) {
        bluetoothController.refreshState()
        _uiState.update {
            it.copy(
                currentScreen = AppScreen.BLUETOOTH_LOBBY,
                lobbyMode = role
            )
        }
        if (role == BluetoothRole.HOST && bluetoothState.value.hasPermissions && bluetoothState.value.isBluetoothEnabled) {
            bluetoothController.startHosting(_uiState.value.localPlayerName)
        }
    }

    fun startHostingTable() {
        bluetoothController.startHosting(_uiState.value.localPlayerName)
    }

    fun connectToHostDevice(address: String) {
        bluetoothController.connectToHost(address, _uiState.value.localPlayerName)
    }

    fun startSoloBotMatch() {
        bluetoothController.disconnect()
        val initial = DominoEngine.startNewMatch(targetScore = 101, isVsBot = true)
        _uiState.update {
            it.copy(
                currentScreen = AppScreen.GAME_TABLE,
                gameState = initial,
                selectedTile = null
            )
        }
        if (initial.currentTurn == PlayerSeat.BOT) {
            scheduleBotTurn()
        }
    }

    fun selectTile(tile: DominoTile) {
        val state = _uiState.value.gameState
        val seat = localSeat()
        if (state.phase != GamePhase.PLAYING || state.currentTurn != seat) return

        val canLeft = DominoEngine.canPlayOnEnd(state, tile, BoardEnd.LEFT)
        val canRight = DominoEngine.canPlayOnEnd(state, tile, BoardEnd.RIGHT)
        if (!canLeft && !canRight) return

        if (state.board.isEmpty()) {
            playTile(tile, BoardEnd.RIGHT)
            return
        }

        if (canLeft && !canRight) {
            playTile(tile, BoardEnd.LEFT)
            return
        }

        if (canRight && !canLeft) {
            playTile(tile, BoardEnd.RIGHT)
            return
        }

        // Tile fits on both ends -> let player pick left or right
        _uiState.update {
            it.copy(selectedTile = if (it.selectedTile?.id == tile.id) null else tile)
        }
    }

    fun playTile(tile: DominoTile, end: BoardEnd) {
        val state = _uiState.value.gameState
        val seat = localSeat()
        if (state.phase != GamePhase.PLAYING || state.currentTurn != seat) return

        if (!state.isVsBot && bluetoothState.value.role == BluetoothRole.GUEST) {
            _uiState.update { it.copy(selectedTile = null) }
            bluetoothController.sendPacket(BluetoothPacket.PlayTile(tile, end))
            return
        }

        DominoEngine.playTile(state, seat, tile, end).onSuccess { updated ->
            _uiState.update { it.copy(gameState = updated, selectedTile = null) }
            if (!updated.isVsBot) {
                bluetoothController.sendPacket(BluetoothPacket.StateSync(updated))
            } else if (updated.phase == GamePhase.PLAYING && updated.currentTurn == PlayerSeat.BOT) {
                scheduleBotTurn()
            }
        }
    }

    fun drawFromBoneyard() {
        val state = _uiState.value.gameState
        val seat = localSeat()
        if (state.phase != GamePhase.PLAYING || state.currentTurn != seat) return

        if (!state.isVsBot && bluetoothState.value.role == BluetoothRole.GUEST) {
            bluetoothController.sendPacket(BluetoothPacket.DrawTile)
            return
        }

        DominoEngine.drawFromBoneyard(state, seat).onSuccess { updated ->
            _uiState.update { it.copy(gameState = updated) }
            if (!updated.isVsBot) {
                bluetoothController.sendPacket(BluetoothPacket.StateSync(updated))
            }
        }
    }

    fun passTurn() {
        val state = _uiState.value.gameState
        val seat = localSeat()
        if (state.phase != GamePhase.PLAYING || state.currentTurn != seat) return

        if (!state.isVsBot && bluetoothState.value.role == BluetoothRole.GUEST) {
            bluetoothController.sendPacket(BluetoothPacket.PassTurn)
            return
        }

        DominoEngine.passTurn(state, seat).onSuccess { updated ->
            _uiState.update { it.copy(gameState = updated) }
            if (!updated.isVsBot) {
                bluetoothController.sendPacket(BluetoothPacket.StateSync(updated))
            } else if (updated.phase == GamePhase.PLAYING && updated.currentTurn == PlayerSeat.BOT) {
                scheduleBotTurn()
            }
        }
    }

    fun requestNextRound() {
        val state = _uiState.value.gameState
        if (!state.isVsBot && bluetoothState.value.role == BluetoothRole.GUEST) {
            bluetoothController.sendPacket(BluetoothPacket.RequestNextRound)
            return
        }
        startNextRoundInternal()
    }

    fun requestNewMatch() {
        val state = _uiState.value.gameState
        if (state.isVsBot) {
            startSoloBotMatch()
            return
        }
        if (bluetoothState.value.role == BluetoothRole.GUEST) {
            bluetoothController.sendPacket(BluetoothPacket.RequestNewMatch)
            return
        }
        val fresh = DominoEngine.startNewMatch(targetScore = 101, isVsBot = false)
        _uiState.update { it.copy(gameState = fresh, selectedTile = null) }
        bluetoothController.sendPacket(BluetoothPacket.StateSync(fresh))
    }

    private fun startNextRoundInternal() {
        val current = _uiState.value.gameState
        val winner = current.lastRoundSummary?.winner
        val next = DominoEngine.startRound(current, winner)
        _uiState.update { it.copy(gameState = next, selectedTile = null) }
        if (!next.isVsBot) {
            bluetoothController.sendPacket(BluetoothPacket.StateSync(next))
        } else if (next.currentTurn == PlayerSeat.BOT) {
            scheduleBotTurn()
        }
    }

    private fun scheduleBotTurn() {
        viewModelScope.launch {
            while (true) {
                delay(750)
                val current = _uiState.value.gameState
                if (!current.isVsBot || current.phase != GamePhase.PLAYING || current.currentTurn != PlayerSeat.BOT) {
                    break
                }
                val result = when (val decision = DominoBot.chooseAction(current)) {
                    is BotDecision.Play -> DominoEngine.playTile(
                        current,
                        PlayerSeat.BOT,
                        decision.move.tile,
                        decision.move.end
                    )
                    BotDecision.Draw -> DominoEngine.drawFromBoneyard(current, PlayerSeat.BOT)
                    BotDecision.Pass -> DominoEngine.passTurn(current, PlayerSeat.BOT)
                }
                val updated = result.getOrNull() ?: break
                _uiState.update { it.copy(gameState = updated) }
                if (updated.currentTurn != PlayerSeat.BOT || updated.phase != GamePhase.PLAYING) {
                    break
                }
            }
        }
    }

    fun setShowRulesDialog(visible: Boolean) {
        _uiState.update { it.copy(showRulesDialog = visible) }
    }

    fun leaveToHome() {
        bluetoothController.disconnect()
        _uiState.update {
            it.copy(
                currentScreen = AppScreen.HOME,
                gameState = DominoGameState(),
                selectedTile = null
            )
        }
    }

    override fun onCleared() {
        super.onCleared()
        bluetoothController.release()
    }
}
