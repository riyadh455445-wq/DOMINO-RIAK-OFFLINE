package com.riak.domino.offline.engine

import kotlin.random.Random

object DominoEngine {

    fun startNewMatch(
        targetScore: Int = 101,
        isVsBot: Boolean = false,
        random: Random = Random.Default
    ): DominoGameState {
        return startRound(
            previousState = DominoGameState(
                roundNumber = 0,
                targetScore = targetScore,
                isVsBot = isVsBot
            ),
            previousRoundWinner = null,
            random = random
        )
    }

    fun startRound(
        previousState: DominoGameState,
        previousRoundWinner: PlayerSeat?,
        random: Random = Random.Default
    ): DominoGameState {
        val shuffled = DominoTile.fullDoubleSixSet().shuffled(random)
        val hostHand = shuffled.subList(0, 7)
        val guestHand = shuffled.subList(7, 14)
        val boneyard = shuffled.subList(14, 28)

        val opponentSeat = previousState.opponentSeat
        val starter = previousRoundWinner ?: determineOpeningSeat(
            hostHand = hostHand,
            guestHand = guestHand,
            opponentSeat = opponentSeat
        )

        val starterLabel = if (starter == PlayerSeat.HOST) "المضيف" else "المنافس"
        return previousState.copy(
            roundNumber = previousState.roundNumber + 1,
            phase = GamePhase.PLAYING,
            board = emptyList(),
            leftEnd = null,
            rightEnd = null,
            hostHand = hostHand,
            guestHand = guestHand,
            boneyard = boneyard,
            currentTurn = starter,
            consecutivePasses = 0,
            lastRoundSummary = null,
            lastActionArabic = "بدأت الجولة ${previousState.roundNumber + 1} · يبدأ $starterLabel"
        )
    }

    private fun determineOpeningSeat(
        hostHand: List<DominoTile>,
        guestHand: List<DominoTile>,
        opponentSeat: PlayerSeat
    ): PlayerSeat {
        val hostHighestDouble = hostHand.filter { it.isDouble }.maxOfOrNull { it.left } ?: -1
        val guestHighestDouble = guestHand.filter { it.isDouble }.maxOfOrNull { it.left } ?: -1

        if (hostHighestDouble != guestHighestDouble) {
            return if (hostHighestDouble > guestHighestDouble) PlayerSeat.HOST else opponentSeat
        }

        val hostHighestPip = hostHand.maxOfOrNull { it.pipSum } ?: -1
        val guestHighestPip = guestHand.maxOfOrNull { it.pipSum } ?: -1
        return if (hostHighestPip >= guestHighestPip) PlayerSeat.HOST else opponentSeat
    }

    fun canPlayOnEnd(state: DominoGameState, tile: DominoTile, end: BoardEnd): Boolean {
        if (state.board.isEmpty()) return true
        val target = when (end) {
            BoardEnd.LEFT -> state.leftEnd
            BoardEnd.RIGHT -> state.rightEnd
        } ?: return true
        return tile.matches(target)
    }

    fun legalMovesForSeat(state: DominoGameState, seat: PlayerSeat): List<LegalMove> {
        if (state.phase != GamePhase.PLAYING || state.currentTurn != seat) return emptyList()
        val hand = state.handFor(seat)
        if (state.board.isEmpty()) {
            return hand.map { LegalMove(it, BoardEnd.RIGHT) }
        }
        val moves = mutableListOf<LegalMove>()
        for (tile in hand) {
            if (canPlayOnEnd(state, tile, BoardEnd.LEFT)) {
                moves.add(LegalMove(tile, BoardEnd.LEFT))
            }
            if (canPlayOnEnd(state, tile, BoardEnd.RIGHT) && state.leftEnd != state.rightEnd) {
                moves.add(LegalMove(tile, BoardEnd.RIGHT))
            } else if (state.leftEnd == state.rightEnd && canPlayOnEnd(state, tile, BoardEnd.RIGHT)) {
                // Allow explicit choice even if both ends carry the same pip value
                if (moves.none { it.tile.id == tile.id && it.end == BoardEnd.RIGHT }) {
                    moves.add(LegalMove(tile, BoardEnd.RIGHT))
                }
            }
        }
        return moves
    }

    fun playTile(
        state: DominoGameState,
        seat: PlayerSeat,
        tile: DominoTile,
        end: BoardEnd
    ): Result<DominoGameState> {
        if (state.phase != GamePhase.PLAYING) {
            return Result.failure(IllegalStateException("المباراة ليست في حالة لعب نشطة"))
        }
        if (state.currentTurn != seat) {
            return Result.failure(IllegalStateException("ليس دور هذا اللاعب"))
        }

        val hand = state.handFor(seat)
        val tileIndex = hand.indexOfFirst { it.id == tile.id }
        if (tileIndex == -1) {
            return Result.failure(IllegalArgumentException("الحجر غير موجود في يد اللاعب"))
        }
        val actualTile = hand[tileIndex]

        val (newBoard, newLeft, newRight) = if (state.board.isEmpty()) {
            Triple(
                listOf(PlacedTile(actualTile, seat)),
                actualTile.left,
                actualTile.right
            )
        } else {
            when (end) {
                BoardEnd.LEFT -> {
                    val leftTarget = state.leftEnd!!
                    if (!actualTile.matches(leftTarget)) {
                        return Result.failure(IllegalArgumentException("الحجر لا يطابق الطرف الأيسر"))
                    }
                    val oriented = if (actualTile.right == leftTarget) actualTile else actualTile.flipped()
                    Triple(
                        listOf(PlacedTile(oriented, seat)) + state.board,
                        oriented.left,
                        state.rightEnd
                    )
                }

                BoardEnd.RIGHT -> {
                    val rightTarget = state.rightEnd!!
                    if (!actualTile.matches(rightTarget)) {
                        return Result.failure(IllegalArgumentException("الحجر لا يطابق الطرف الأيمن"))
                    }
                    val oriented = if (actualTile.left == rightTarget) actualTile else actualTile.flipped()
                    Triple(
                        state.board + PlacedTile(oriented, seat),
                        state.leftEnd,
                        oriented.right
                    )
                }
            }
        }

        val updatedHand = hand.toMutableList().apply { removeAt(tileIndex) }
        val updatedHostHand = if (seat == PlayerSeat.HOST) updatedHand else state.hostHand
        val updatedGuestHand = if (seat != PlayerSeat.HOST) updatedHand else state.guestHand
        val nextTurn = if (seat == PlayerSeat.HOST) state.opponentSeat else PlayerSeat.HOST
        val seatArabic = if (seat == PlayerSeat.HOST) "المضيف" else "المنافس"

        var nextState = state.copy(
            board = newBoard,
            leftEnd = newLeft,
            rightEnd = newRight,
            hostHand = updatedHostHand,
            guestHand = updatedGuestHand,
            currentTurn = nextTurn,
            consecutivePasses = 0,
            lastActionArabic = "وضع $seatArabic الحجر [${actualTile.left}|${actualTile.right}]"
        )

        if (updatedHand.isEmpty()) {
            nextState = finishRound(nextState, winner = seat, reason = RoundEndReason.DOMINO_OUT)
        }
        return Result.success(nextState)
    }

    fun drawFromBoneyard(state: DominoGameState, seat: PlayerSeat): Result<DominoGameState> {
        if (state.phase != GamePhase.PLAYING) {
            return Result.failure(IllegalStateException("لا يمكن السحب خارج اللعب"))
        }
        if (state.currentTurn != seat) {
            return Result.failure(IllegalStateException("ليس دورك للسحب"))
        }
        if (state.boneyard.isEmpty()) {
            return Result.failure(IllegalStateException("البنك فارغ"))
        }
        if (legalMovesForSeat(state, seat).isNotEmpty()) {
            return Result.failure(IllegalStateException("لديك حجر صالح للعب"))
        }

        val drawn = state.boneyard.first()
        val remainingBoneyard = state.boneyard.drop(1)
        val updatedHostHand = if (seat == PlayerSeat.HOST) state.hostHand + drawn else state.hostHand
        val updatedGuestHand = if (seat != PlayerSeat.HOST) state.guestHand + drawn else state.guestHand
        val seatArabic = if (seat == PlayerSeat.HOST) "المضيف" else "المنافس"

        return Result.success(
            state.copy(
                hostHand = updatedHostHand,
                guestHand = updatedGuestHand,
                boneyard = remainingBoneyard,
                consecutivePasses = 0,
                lastActionArabic = "سحب $seatArabic حجراً من البنك (${remainingBoneyard.size} متبقٍ)"
            )
        )
    }

    fun passTurn(state: DominoGameState, seat: PlayerSeat): Result<DominoGameState> {
        if (state.phase != GamePhase.PLAYING) {
            return Result.failure(IllegalStateException("لا يمكن التمرير خارج اللعب"))
        }
        if (state.currentTurn != seat) {
            return Result.failure(IllegalStateException("ليس دورك للتمرير"))
        }
        if (legalMovesForSeat(state, seat).isNotEmpty()) {
            return Result.failure(IllegalStateException("لديك حجر متاح ولا يمكنك التمرير"))
        }
        if (state.boneyard.isNotEmpty()) {
            return Result.failure(IllegalStateException("يجب السحب من البنك قبل التمرير"))
        }

        val newPasses = state.consecutivePasses + 1
        val nextTurn = if (seat == PlayerSeat.HOST) state.opponentSeat else PlayerSeat.HOST
        val seatArabic = if (seat == PlayerSeat.HOST) "المضيف" else "المنافس"

        val updated = state.copy(
            currentTurn = nextTurn,
            consecutivePasses = newPasses,
            lastActionArabic = "مرّر $seatArabic الدور"
        )

        return if (newPasses >= 2) {
            val hostPips = updated.hostHand.sumOf { it.pipSum }
            val guestPips = updated.guestHand.sumOf { it.pipSum }
            val winner = when {
                hostPips < guestPips -> PlayerSeat.HOST
                guestPips < hostPips -> updated.opponentSeat
                else -> null
            }
            Result.success(finishRound(updated, winner = winner, reason = RoundEndReason.BLOCKED_BOARD))
        } else {
            Result.success(updated)
        }
    }

    private fun finishRound(
        state: DominoGameState,
        winner: PlayerSeat?,
        reason: RoundEndReason
    ): DominoGameState {
        val hostPips = state.hostHand.sumOf { it.pipSum }
        val guestPips = state.guestHand.sumOf { it.pipSum }

        val pointsAwarded = when (winner) {
            PlayerSeat.HOST -> guestPips
            PlayerSeat.GUEST, PlayerSeat.BOT -> hostPips
            null -> 0
        }

        val newHostScore = state.hostScore + if (winner == PlayerSeat.HOST) pointsAwarded else 0
        val newGuestScore = state.guestScore + if (winner != null && winner != PlayerSeat.HOST) pointsAwarded else 0
        val isMatchOver = newHostScore >= state.targetScore || newGuestScore >= state.targetScore

        val summary = RoundSummary(
            roundNumber = state.roundNumber,
            winner = winner,
            reason = reason,
            pointsAwarded = pointsAwarded,
            hostRemainingPips = hostPips,
            guestRemainingPips = guestPips
        )

        val statusText = when {
            winner == null -> "أُغلقت الطاولة بالتعادل"
            reason == RoundEndReason.DOMINO_OUT -> {
                val w = if (winner == PlayerSeat.HOST) "المضيف" else "المنافس"
                "دومينو! فاز $w بـ $pointsAwarded نقطة"
            }
            else -> {
                val w = if (winner == PlayerSeat.HOST) "المضيف" else "المنافس"
                "انغلقت الطاولة · فاز $w بـ $pointsAwarded نقطة"
            }
        }

        return state.copy(
            phase = if (isMatchOver) GamePhase.MATCH_OVER else GamePhase.ROUND_OVER,
            hostScore = newHostScore,
            guestScore = newGuestScore,
            lastRoundSummary = summary,
            lastActionArabic = statusText
        )
    }
}
