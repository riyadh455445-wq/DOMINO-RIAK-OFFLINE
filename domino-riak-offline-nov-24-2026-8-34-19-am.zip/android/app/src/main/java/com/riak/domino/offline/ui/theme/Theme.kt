package com.riak.domino.offline.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.sp

object RiakColors {
    val ObsidianBlack = Color(0xFF070C0A)
    val EmeraldDeep = Color(0xFF04291E)
    val EmeraldFelt = Color(0xFF073B2B)
    val EmeraldSurface = Color(0xFF0B241C)
    val ChampagneGold = Color(0xFFD4AF37)
    val GoldBright = Color(0xFFF0D27A)
    val GoldMuted = Color(0xFF8C732A)
    val IvoryTile = Color(0xFFFAF6EC)
    val IvoryEdge = Color(0xFFE5DAC0)
    val PipObsidian = Color(0xFF101815)
    val TextIvory = Color(0xFFF7F3E8)
    val TextMuted = Color(0xFFA7B8B0)
    val DangerRuby = Color(0xFFD9534F)
}

private val DominoDarkColorScheme = darkColorScheme(
    primary = RiakColors.ChampagneGold,
    onPrimary = RiakColors.ObsidianBlack,
    secondary = RiakColors.EmeraldFelt,
    onSecondary = RiakColors.TextIvory,
    background = RiakColors.ObsidianBlack,
    onBackground = RiakColors.TextIvory,
    surface = RiakColors.EmeraldSurface,
    onSurface = RiakColors.TextIvory,
    surfaceVariant = RiakColors.EmeraldDeep,
    onSurfaceVariant = RiakColors.TextMuted,
    outline = RiakColors.GoldMuted
)

private val DominoTypography = Typography(
    headlineLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 28.sp,
        lineHeight = 36.sp
    ),
    titleLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 20.sp,
        lineHeight = 28.sp
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 16.sp,
        lineHeight = 22.sp
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp,
        lineHeight = 21.sp
    ),
    labelLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 14.sp
    )
)

@Composable
fun DominoRiakTheme(content: @Composable () -> Unit) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            colorScheme = DominoDarkColorScheme,
            typography = DominoTypography,
            content = content
        )
    }
}
