# DOMINO RIAK OFFLINE — دومينو رياك أوفلاين

تطبيق أندرويد أصلي (**Native Kotlin + Jetpack Compose**) للعب الدومينو الجماعي أوفلاين عبر **البلوتوث المباشر (Classic Bluetooth RFCOMM)** بدون الحاجة إلى إنترنت أو خوادم خارجية.

- **المالك والمطور**: RIAK
- **الحزمة**: `com.riak.domino.offline`
- **الحد الأدنى لنظام أندرويد**: Android 8.0 (API 26) · **المستهدف**: Android 15 (API 35)

## البنية البرمجية للمشروع
- `engine/DominoModels.kt`: تمثيل أحجار الدومينو الـ 28 وحالة الطاولة والجولات.
- `engine/DominoEngine.kt`: محرك القواعد الكامل (التوزيع، التطابق، السحب من البنك، التمرير، حساب الإغلاق والـ 101 نقطة).
- `engine/DominoBot.kt`: خصم محلي ذكي للتدريب الفردي بدون بلوتوث.
- `bluetooth/BluetoothProtocol.kt`: بروتوكول مراسلة JSON ثنائي الاتجاه عبر `kotlinx.serialization`.
- `bluetooth/BluetoothController.kt`: إدارة `BluetoothServerSocket` للمضيف و`BluetoothSocket` للضيف واكتشاف الأجهزة القريبة وصلاحيات Android 12+.
- `ui/`: واجهات Jetpack Compose بالعربية الكاملة (RTL) بهوية الزمرد الداكن والأسود والذهب والعاج.

## خطوات التشغيل في Android Studio
1. افتح مجلد `android/` داخل **Android Studio** (Ladybug أو أحدث).
2. انتظر مزامنة Gradle (`libs.versions.toml`).
3. ثبّت التطبيق على هاتفين أندرويد حقيقيين عبر USB (المحاكي لا يدعم البلوتوث الحقيقي بين جهازين).
4. في الجهاز الأول اختر **إنشاء طاولة بلوتوث** وفعّل الرؤية، وفي الجهاز الثاني اختر **الانضمام لطاولة عبر البلوتوث** واتصل بالجهاز الأول.
